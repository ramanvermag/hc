package com.high.court.utility;

public class Constants {
	public static final String PARAMETER_SEP = "&";
	public static final String PARAMETER_EQUALS = "=";
	public static final String TRANS_URL = "http://highcourtbarassociations.com/api/web/payment";
}