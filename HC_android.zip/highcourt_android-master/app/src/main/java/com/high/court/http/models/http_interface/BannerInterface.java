package com.high.court.http.models.http_interface;

import com.high.court.http.models.BannnerModel;

/**
 * Created by bhavan on 5/24/17.
 */

public interface BannerInterface {

    void onSuccess(BannnerModel bannnerModel);

    void onBannerError(Throwable t);

}
