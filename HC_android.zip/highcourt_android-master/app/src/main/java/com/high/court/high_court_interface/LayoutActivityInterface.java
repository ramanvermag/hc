package com.high.court.high_court_interface;

/**
 * Created by Akshit on 26/04/2017.
 */

public interface LayoutActivityInterface {

    void onClickForgotPassword();
    
}
