package com.high.court.layouts;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

/**
 * Created by Akshit on 04/05/2017.
 */

public class HighCourtCalender extends MaterialCalendarView {

    public HighCourtCalender(@NonNull Context context) {
        super(context);

    }

    public HighCourtCalender(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

}
