package com.high.court.activities;

import android.os.Bundle;

import com.high.court.R;

public class ForgotPasswordActivity extends HighCourtActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
    }
}
