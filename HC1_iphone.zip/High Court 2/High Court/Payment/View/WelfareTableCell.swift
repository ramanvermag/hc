//
//  WelfareTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 25/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class WelfareTableCell: UITableViewCell {

    @IBOutlet weak var lblFirst: UILabel!
    @IBOutlet weak var lblSecond: UILabel!
    @IBOutlet weak var viewDateTime: UIView!
    @IBOutlet weak var btnStartYear: UIButton!
    @IBOutlet weak var btnEndYear: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        buttonBorder().buttonBorder(sender: btnStartYear)
        buttonBorder().buttonBorder(sender: btnEndYear)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnYear(_ sender: UIButton) {
        switch sender.tag {
        case 0:
    /// Start Year button Action
            break
        case 1:
    /// End Year button Action
            break
        default:
            break
        }
    }
    
}
