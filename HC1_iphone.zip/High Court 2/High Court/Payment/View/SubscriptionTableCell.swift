//
//  SubscriptionTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 25/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import CoreActionSheetPicker

class SubscriptionTableCell: UITableViewCell {

    @IBOutlet weak var lblFirst: UILabel!
    @IBOutlet weak var lblSecond: UILabel!
    
    @IBOutlet weak var viewButtons: UIView!
    @IBOutlet weak var btnYear: UIButton!
    @IBOutlet weak var btnMonth: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        buttonBorder().buttonBorder(sender: btnYear)
        buttonBorder().buttonBorder(sender: btnMonth)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnMonYearAction(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            /// Year button Action
            ActionSheetStringPicker.show(withTitle: "Select Year", rows: ["2017", "2018", "2019", "2020"], initialSelection: 0, doneBlock: { (picker, index, value) in
                print("sender values = \(value)")
                print("sender indexes = \(index)")
                print("sender picker = \(picker)")
            }, cancel: { (ActionSheetStringPicker) in
                return
            }, origin: sender)
            break
        case 0:
            /// Month button Action
            ActionSheetStringPicker.show(withTitle: "Select Month", rows: ["Jan", "Feb", "Mar", "Apr", "May", "June"], initialSelection: 0, doneBlock: { (picker, index, value) in
                print("sender values = \(value)")
                print("sender indexes = \(index)")
                print("sender picker = \(picker)")
            }, cancel: { (ActionSheetStringPicker) in
                return
            }, origin: sender)
            break
        default:
            break
        }
    }

}

struct buttonBorder {
    func buttonBorder(sender: UIButton) {
        sender.layer.borderWidth = 1
        sender.layer.borderColor = UIColor.lightGray.cgColor
        let w = sender.frame.width
//        sender.imageEdgeInsets = UIEdgeInsetsMake(0,w * 0.65, 0, 0)
        sender.titleEdgeInsets = UIEdgeInsetsMake(0,-(w * 0.8), 0, 0)
    }
}
