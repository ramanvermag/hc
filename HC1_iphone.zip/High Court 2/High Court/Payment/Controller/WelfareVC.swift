//
//  WelfareVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 25/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class WelfareVC: UIViewController {

    @IBOutlet weak var viewWelfare: UIView!
    @IBOutlet weak var tableWelfare: UITableView!
    @IBOutlet weak var tableWelfareHistory: UITableView!
    
    @IBOutlet weak var lblDateTime: UILabel!
    @IBOutlet weak var lblDue: UILabel!

    struct tableId {
        static let welfare    = "WelfareTableCell"
        static let payHistory = "PaymentHistoryTableCell"
    }
    
    let arrTitle = ["Employee welfare fund", "", "(Rs. 200P.M x 3)", "Total"]
    let arrValue = ["Dec, 2016", "", "Rs. 600", "Rs. 600"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableWelfare.register(UINib(nibName: tableId.welfare, bundle: nil), forCellReuseIdentifier: tableId.welfare)
        Common.s.tableSeperator(tableView: self.tableWelfare)
        Common.s.tableSeperator(tableView: self.tableWelfareHistory)
        lblDue.layer.cornerRadius = 15
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnpayAction(_ sender: UIButton) {
    }
}
extension WelfareVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.isEqual(tableWelfare) {
            let cell = tableView.dequeueReusableCell(withIdentifier: tableId.welfare, for: indexPath) as! WelfareTableCell
            
            cell.lblFirst.text = self.arrTitle[indexPath.row]
            cell.lblSecond.text = self.arrValue[indexPath.row]
            
            cell.viewDateTime.isHidden = true
            if indexPath.row == 1 {
                cell.viewDateTime.isHidden = false
            }
            if indexPath.row == 3 {
                cell.backgroundColor = UIColor(red: 227/255, green: 224/255, blue: 211/255, alpha: 1)
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: tableId.payHistory, for: indexPath)
            return cell
        }
    }
}
extension WelfareVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.isEqual(tableWelfare) {
            return 60
        } else {
            return 55
        }
    }
}
