//
//  PaymentVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 25/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class PaymentVC: UIViewController {
    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var btnSubscription: UIButton!
    @IBOutlet weak var btnWelfare: UIButton!

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewSubscription: UIView!
        
    @IBOutlet weak var tableSubscription: UITableView!
    @IBOutlet weak var tablePayHistory: UITableView!
    
    @IBOutlet weak var lblDateAmount: UILabel!
    @IBOutlet weak var lblDue: UILabel!
    
    @IBOutlet weak var constraintScrollBottom: NSLayoutConstraint!
    var welfare = WelfareVC()
    var layer = UIView()
    let layerColor = UIColor(red: 227/255, green: 224/255, blue: 211/255, alpha: 1)
    
    
    struct tableId {
        static let subscription = "SubscriptionTableCell"
        static let payHistory   = "PaymentHistoryTableCell"
    }
    
    let arrTitle = ["Subscription paid upto", "Pay from", "Pay till", "Membership Subscription", "(Rs. 200P.M x 3)", "Total"]
    let arrValue = ["Dec, 2016", "", "", "Dec, 2017", "Rs. 600", "Rs. 600"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        Common.s.navColor(sender: self)
        welfare = self.storyboard?.instantiateViewController(withIdentifier: "WelfareVCID") as! WelfareVC
        self.addChildViewController(welfare)
        
        welfare.view.frame = self.scrollView.bounds
        self.scrollView.addSubview(welfare.view)
        
        welfare.view.isHidden = true

        self.tableSubscription.register(UINib(nibName: tableId.subscription, bundle: nil), forCellReuseIdentifier: tableId.subscription)

        lblDue.layer.cornerRadius = 15
        
        layer = UIView(frame: CGRect(x: 0, y: self.viewTop.frame.height - 2, width: Common.s.screenSize.width / 2, height: 2))
        self.viewTop.addSubview(layer)
        self.addLayer(x: 0, btn: self.btnSubscription)

        Common.s.tableSeperator(tableView: self.tableSubscription)
        Common.s.tableSeperator(tableView: self.tablePayHistory)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.setScrollViewContentSize()
    }
    
//    override func viewWillLayoutSubviews() {
//        super.viewWillLayoutSubviews()
//        self.scrollView.contentSize = CGSize(width: Common.s.screenSize.width, height:constraintScrollBottom.constant)
//    }
    
    func setScrollViewContentSize() {
        
        var height: CGFloat
        let lastView = self.scrollView.subviews[0].subviews.last!
        print(lastView.debugDescription) // should be what you expect
        
        let lastViewYPos = lastView.convert(lastView.frame.origin, to: nil).y  // this is absolute positioning, not relative
        let lastViewHeight = lastView.frame.size.height
        
        // sanity check on these
        print(lastViewYPos)
        print(lastViewHeight)
        
        height = lastViewYPos + lastViewHeight
        
        print("setting scroll height: \(Common.s.screenSize.height - 50)")
        
//        scrollView.contentSize.height = constraintScrollBottom.constant
//        scrollView.contentSize.height = Common.s.screenSize.height - 50
        scrollView.contentSize.height = 686
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnPayAction(_ sender: UIButton) {
    }
    
    @IBAction func btnSubscribeWelfareAction(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            viewSubscription.isHidden = false
            welfare.view.isHidden = true
            self.addLayer(x: 0, btn: sender)
            break
        case 1:
            viewSubscription.isHidden = true
            welfare.view.isHidden = false
            self.addLayer(x: Common.s.screenSize.width / 2, btn: sender)
            break
        default:
            break
        }
    }
    
    func addLayer(x: CGFloat, btn: UIButton) {
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseInOut, animations: {
            self.layer.backgroundColor = Common.s.appColor
            self.layer.frame.origin.x = x
            self.layer.layoutIfNeeded()
            
            self.btnSubscription.setTitleColor(UIColor.black, for: .normal)
            self.btnWelfare.setTitleColor(UIColor.black, for: .normal)
            self.btnWelfare.backgroundColor = self.layerColor
            self.btnSubscription.backgroundColor = self.layerColor
            
            btn.backgroundColor = UIColor.white
            btn.setTitleColor(Common.s.appColor, for: .normal)
        }, completion: nil)
    }
    
}
extension PaymentVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.isEqual(tableSubscription) {
            return 6
        } else {
            return 10
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.isEqual(tableSubscription) {
            let cell = tableView.dequeueReusableCell(withIdentifier: tableId.subscription, for: indexPath) as! SubscriptionTableCell
            
            cell.lblFirst.text = self.arrTitle[indexPath.row]
            cell.lblSecond.text = self.arrValue[indexPath.row]
            cell.bringSubview(toFront: cell.lblFirst)
            
            cell.viewButtons.isHidden = true
            if indexPath.row > 0 && indexPath.row < 3 {
                cell.viewButtons.isHidden = false
            }
            if indexPath.row == 5 {
                cell.backgroundColor = self.layerColor
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: tableId.payHistory, for: indexPath)
            return cell
        }
    }
}
extension PaymentVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.isEqual(tableSubscription) {
            return 60
        } else {
            return 55
        }
    }
}
