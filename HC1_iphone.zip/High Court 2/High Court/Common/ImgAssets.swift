//
//  ImgAssets.swift
//  High Court
//
//  Created by Karun Aggarwal on 24/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

struct ImgAssets {
    struct SideMenu {
        static let myprofile = "myProfile"
        static let subscription = "Subscription"
        static let changePass = "changePassword"
        static let logout     = "logout"
    }
}
