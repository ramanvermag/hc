//
//  Common.swift
//  High Court
//
//  Created by Karun Aggarwal on 16/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import Foundation
import UIKit

class Common: NSObject {
    
    class var s: Common {
        struct Static {
            static let instance: Common = Common()
        }
        return Static.instance
    }
    
    let screenSize = UIScreen.main.bounds
    let appColor   = UIColor(red: 217/255, green: 162/255, blue: 49/255, alpha: 1)

/// Activity Indicator
    var container: UIView = UIView()
    var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    
/// Table View Row Seperator
    func tableSeperator(tableView: UITableView) {
        tableView.separatorStyle  = .singleLine
        tableView.separatorInset  = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        tableView.separatorColor  = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        tableView.tableFooterView = UIView()
    }
    
/// navigation bar colors
    func navColor(sender: UIViewController, clear: Bool = false) {
        sender.navigationController?.navigationBar.barTintColor = clear == false ? appColor : UIColor.clear
    }
    
/// tableview accessory next icon
    func accessoryView(table: UITableViewCell) {
        table.accessoryView = UIImageView(image: #imageLiteral(resourceName: "next-arrow"))
    }
    
/// Image rounded corner radius
    func cornerRadius(img: UIImageView) {
        img.layer.cornerRadius = img.bounds.midY
    }
    
/// height according to string
    func getHeight(messageString: String) -> CGFloat{
        let attributes : [String : Any] = [NSFontAttributeName : UIFont.systemFont(ofSize: 16.0)]
        
        let attributedString : NSAttributedString = NSAttributedString(string: messageString, attributes: attributes)
        
        let rect : CGRect = attributedString.boundingRect(with: CGSize(width: Common.s.screenSize.width - 16, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
        
        return (rect.height)
    }
    
/// textfield validation
    func validateTextfield(sender: UITextField, alertText: String, controller: UIViewController) -> Bool {
        if sender.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) == "" {
            sender.becomeFirstResponder()
            controller.present(self.alertMessage("\(alertText) cannot be blank."), animated: true, completion: nil)
            return true
        }
        return false
    }
    
/// Email validation
    func isValidEmail(testStr: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
/// Alert Message
    func alertMessage(_ msg: String) -> UIAlertController {
        let alert = UIAlertController(title: "Chandigarh High Court", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        return alert
    }
    
/// Loader - Activity Indicator
    func showActivityIndicator(_ uiView: UIView) {
        self.container.frame = CGRect(x: 0, y: 0, width: screenSize.width, height: screenSize.height)
        self.container.backgroundColor = UIColor(red: 18/255, green: 6/255, blue: 0/255, alpha: 0.3)
        
        self.loadingView.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
        loadingView.center = container.center
        loadingView.clipsToBounds = true
        loadingView.layer.cornerRadius = 10
        
        activityIndicator.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0);
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.white
        activityIndicator.center = CGPoint(x: loadingView.frame.size.width / 2, y: loadingView.frame.size.height / 2)
        loadingView.addSubview(activityIndicator)
        container.addSubview(loadingView)
        uiView.addSubview(container)
        uiView.bringSubview(toFront: container)
        activityIndicator.startAnimating()
    }
    
    func hideActivityIndicator() {
        activityIndicator.stopAnimating()
        container.removeFromSuperview()
    }
}
