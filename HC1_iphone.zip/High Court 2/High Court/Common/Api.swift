//
//  Api.swift
//  High Court
//
//  Created by Karun Aggarwal on 27/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import Alamofire

class Api: NSObject {
    class var s: Api {
        struct Static {
            static let instance: Api = Api()
        }
        return Static.instance
    }
    
    let baseurl = "http://uniquecoders.in/highcourt/api/web/v1/"
//    let baseurl = "http://192.168.1.100/highcourt/api/web/v1/"
    let version = ""

    var base: String { return baseurl + version }
    var login: String { return base + "user/login" }
    var resetPass: String { return base + "user/reset-password" }
    var requestResetPass: String { return base + "user/request-reset-password" }
    var judgeList: String { return base + "judges/list" }
    var executive: String { return base + "user/executive" }
    var updateProfile: String { return base + "profile/update" }
    var bloodGroup: String { return base + "user/blood-group-list" }
    var memberDirectory: String { return base + "user/members" }
    var notification: String { return base + "notification/list" }
    var caselaw: String { return base + "case-law/list" }
    var roster: String { return base + "roster/list" }
    var holiday: String { return base + "holidays/list" }
    var banner: String { return base + "bannner/list-all" }
    var achievement: String { return base + "achievements/list" }
    var notificationRead: String { return base + "notification/read" }
    var caselawRead: String { return base + "case-law/read" }
    var notificationCount: String { return base + "notification/un-read-count" }
    
    func isConnectedToInternet() -> Bool {
        return NetworkReachabilityManager()!.isReachable
    }
    
/// POST METHOD
    func post(controller: UIViewController, method: String, param: NSDictionary, completion: @escaping (_ result: NSDictionary?) ->()) {
        if isConnectedToInternet() == false {
            controller.present(Common.s.alertMessage("Internet connection seems unavailable."), animated: true, completion: nil)
            completion(nil)
            return
        }
        Common.s.showActivityIndicator(controller.view)
        Alamofire.request(method, method: .post, parameters: param as? Parameters)
            .validate(statusCode: 200..<300)
            .responseJSON(completionHandler: { (response) in
                print(response.response!)
                print(response.result.value.debugDescription)
                Common.s.hideActivityIndicator()
                switch response.result {
                case .success:
                    completion(response.result.value as! NSDictionary?)
                    break
                case .failure:
                    break
                }
        })
    }
    
    func postHeader(controller: UIViewController, method: String, param: NSDictionary, header: [String: String], completion: @escaping (_ result: NSDictionary?) ->()) {
        if isConnectedToInternet() == false {
            controller.present(Common.s.alertMessage("Internet connection seems unavailable."), animated: true, completion: nil)
            completion(nil)
            return
        }
        Common.s.showActivityIndicator(controller.view)
        if method == notificationRead {
            Common.s.hideActivityIndicator()
        }
        Alamofire.request(method, method: .post, parameters: param as? Parameters, headers: header)
            .validate(statusCode: 200..<300)
            .responseJSON(completionHandler: { (response) in
                print(response.response!)
                print(response.result.value.debugDescription)
                Common.s.hideActivityIndicator()
                switch response.result {
                case .success:
                    completion(response.result.value as! NSDictionary?)
                    break
                case .failure:
                    break
                }
        })
    }
    
    func uploadImage(controller: UIViewController, filename: String, param: [String: String], img: UIImage, tokenId: String, completion: @escaping (_ result: NSDictionary?) ->())
    {
        Common.s.showActivityIndicator(controller.view)
        let myUrl = NSURL(string: self.updateProfile)
        
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "POST";
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue(tokenId, forHTTPHeaderField: "highcourt-header-token")
        
        let imageData = UIImageJPEGRepresentation(img, 0.25)
        print("\nimageData- \(imageData)\nfilename: \(filename)\nparam: \(param)\nimg \(img)\ntokenid: \(tokenId)\n")
        
        let body = createBodyWithParameters(parameters: param, filePathKey: "UploadForm[imageFile]", imageDataKey: imageData! as NSData, boundary: boundary, fileName: filename)
        //        request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
        request.httpBody = body as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            Common.s.hideActivityIndicator()
            if error != nil {
                print("error=\(error)")
//                Common.s.hideActivityIndicator()
                controller.present(Common.s.alertMessage("Something went wrong!\n Please try again later!"), animated: true, completion: nil)
                completion(nil)
                return
            }
            if let responseStatus = response as? HTTPURLResponse {
                print("***** response = \(response)")
                Common.s.hideActivityIndicator()
                if responseStatus.statusCode != 200 {
                    DispatchQueue.main.async(execute: {
                        controller.present(Common.s.alertMessage("Something went wrong!\n Please try again."), animated: true, completion: nil)
//                        Common.s.hideActivityIndicator()
                        completion(nil)
                    })
                } else {
//                    Common.s.hideActivityIndicator()
                    if responseStatus.statusCode == 200 {
                        DispatchQueue.main.async(execute: {
                            //You can print out response object
                            
//                            Common.s.hideActivityIndicator()
                            // Print out reponse body
                            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                            print("**** response data = \(responseString!)")
                            
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary

                                print("\n---------- \(NSString(data: data!, encoding:String.Encoding.utf8.rawValue)!)\n\n")
                                print("\n ------- \(json) -----\n\n")

                                if json?.value(forKey: "is_success") as! Bool {
                                    controller.present(Common.s.alertMessage("Your proile was updated successfully."), animated: true, completion: nil)
                                } else {
                                    controller.present(Common.s.alertMessage("Your proile wasn't updated successfully. Please try again later!"), animated: true, completion: nil)
                                }
                                completion(json)
                            } catch let err {
//                                Common.s.hideActivityIndicator()
                                controller.present(Common.s.alertMessage("Your proile wasn't updated successfully. Please try again later!"), animated: true, completion: nil)
                                print(err)
                                completion(nil)
                            }
                        })
                    } else {
//                        Common.s.hideActivityIndicator()
                        controller.present(Common.s.alertMessage("Your proile wasn't updated successfully. Please try again later!"), animated: true, completion: nil)
                        completion(nil)
                    }
                }
            }
        }
        task.resume()
    }
    
    func createBodyWithParameters(parameters:[String:String]?, filePathKey: String, imageDataKey:NSData, boundary: String, fileName: String) -> NSData {
        let body = NSMutableData()
        let tempData = NSMutableData()
        for (key, value) in parameters! {
            tempData.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("\(value)\r\n".data(using: String.Encoding.utf8)!)
        }
        
        //        print("self.imageArray.count - \(self.imageArray.count)")
        //        for i in 0..<self.imageArray.count {
        //            print("self.imageArray.count index - \(i)")
        if fileName != "" {
            var mimeType = ""
            let mime = fileName.components(separatedBy: ".")
            //            print("\n\n image name = \(self.imageName[i])  mime - 1 = \(mime[0]) (2 = \(mime[1]))")
            
            switch mime[mime.count - 1].lowercased() {
            case "jpg":
                mimeType = "image/jpg"
                break
            case "jpeg":
                mimeType = "image/jpeg"
                break
            case "png":
                mimeType = "image/jpeg"
                break
            default:
                break
            }
            print("\n\ntempData to upload image 1- \(String(data: tempData as Data, encoding: String.Encoding.utf8))\n\n")
            
            tempData.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(fileName)\"\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("Content-Type: \(mimeType)\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("Content-Transfer-Encoding: binary\r\n\r\n".data(using: String.Encoding.utf8)!)
            tempData.append(imageDataKey as Data)
            tempData.append("\r\n".data(using: String.Encoding.utf8)!)
            tempData.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            
            print("\n\ntempData to upload image- \(String(data: tempData as Data, encoding: String.Encoding.utf8))\n\n")
        }

        body.append(tempData as Data)
        
        return body
    }
    
    func generateBoundaryString() -> String
    {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
}
