//
//  ApiData.swift
//  High Court
//
//  Created by Karun Aggarwal on 27/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ApiData: NSObject {
    class var s: ApiData {
        struct Static {
            static let instance: ApiData = ApiData()
        }
        return Static.instance
    }
    
    var executive = NSDictionary()
    
    let userDefault = UserDefaults.standard
    
    func archivedData(data: Any) -> Data {
        return NSKeyedArchiver.archivedData(withRootObject: data)
    }
    
    func unarchiveData(for data: Data) -> NSDictionary {
        return NSKeyedUnarchiver.unarchiveObject(with: data) as! NSDictionary
    }
    
    func setImage(image: UIImageView ,img: String) {
        image.kf.setImage(with: URL(string: img), placeholder: #imageLiteral(resourceName: "defaultJudge"), options: [.transition(.fade(0.1))], progressBlock: nil, completionHandler: nil)
    }
    
    func btnCall(controler: UIViewController, _ sender: UIButton) {
        let mobile = sender.titleLabel?.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        guard mobile != "" else {
            return
        }
        if let phone = mobile {
//            let alert = UIAlertController(title: "Chandigarh High Court", message: "Do you want to call \(phone)?", preferredStyle: .alert)
            let alert = UIAlertController(title: "Chandigarh High Court", message: "Do you want to call now?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Later", style: .destructive, handler: nil))
            alert.addAction(UIAlertAction(title: "Now", style: .default, handler: { (action) in
                if phone.contains(",") {
                    let p = phone.components(separatedBy: ",")
                    let c = p[0].trimmingCharacters(in: .whitespacesAndNewlines)
                    UIApplication.shared.openURL(NSURL(string: "tel://\(c)") as! URL)
                } else {
                    UIApplication.shared.openURL(NSURL(string: "tel://\(phone)") as! URL)
                }
            }))
            controler.present(alert, animated: true, completion: nil)
        }
    }
}

struct UserDefaultVariables {
    static let user = "user"
    static let user_id = "user_id"
    static let logout = "logout"
}
