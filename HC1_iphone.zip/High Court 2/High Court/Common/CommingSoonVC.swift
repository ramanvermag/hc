//
//  CommingSoonVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 24/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class CommingSoonVC: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    var webUrl = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Common.s.navColor(sender: self)
        webView.isHidden = true
        if webUrl != "" {
            webView.isHidden = false
            let req = URLRequest(url: URL(string: webUrl)!, cachePolicy: .returnCacheDataElseLoad, timeoutInterval: 5.0)
            webView.loadRequest(req)
            webUrl = ""
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
