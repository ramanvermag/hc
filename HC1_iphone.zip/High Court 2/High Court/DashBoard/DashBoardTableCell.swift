//
//  DashBoardTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 03/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

var notifyRead = ["notify": false, "caselaw": false]

class DashBoardTableCell: UITableViewCell {

    @IBOutlet weak var imgIcon: UIImageView!
    @IBOutlet weak var lblOptionName: UILabel!
    @IBOutlet weak var lblNumber: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func showNumber(show: Bool, text: String) {
        self.lblNumber.isHidden = show
        if text != "" {
            if Int(text)! > 0 {
                self.lblNumber.text = text
            } else {
                self.lblNumber.isHidden = true
            }
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

struct BannerList {
    var dict = NSDictionary()
    
    init() {
    }
    
    init(o: NSDictionary) {
        dict = o
    }
    
    var image_path: String {
        return getSet(val: dict.value(forKey: "image_path"))
    }
    
    func getSet(val: Any?) -> String {
        if val != nil {
            if let notNull =  val as? String {
                return notNull
            } else {
                return ""
            }
        } else {
            return ""
        }
    }
}

struct NotificationCount {
    var dict = NSDictionary()
    
    init(o: NSDictionary) {
        dict = o
    }
    
    var un_read_count: String {
        guard let blood = dict.value(forKey: "un_read_count") else { return "" }
        return Roster().getSet(val: blood)
    }
    
    var case_law_count: String {
        guard let court = dict.value(forKey: "case_law_count") else { return "" }
        return Roster().getSet(val: court)
    }
}


