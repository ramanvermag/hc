//
//  SideMenuVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class SideMenuVC: UIViewController {

    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    let arrName = ["MY PROFILE", "PAY MY DUES", "CHANGE PASSWORD", "LOGOUT"]
    let arrImage = [ImgAssets.SideMenu.myprofile, ImgAssets.SideMenu.subscription, ImgAssets.SideMenu.changePass, ImgAssets.SideMenu.logout]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Common.s.tableSeperator(tableView: self.tableView)
        Common.s.cornerRadius(img: imgUser)
        
        self.view.bringSubview(toFront: self.imgUser)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    func updateSideMenu() {
        let u = ApiData.s.unarchiveData(for: ApiData.s.userDefault.object(forKey: UserDefaultVariables.user) as! Data)
        
        if (u.count) > 0 {
            ApiData.s.userDefault.set(u["user_id"] as? Int64, forKey: UserDefaultVariables.user_id)
            ApiData.s.userDefault.synchronize()
            
            self.lblUserName.text = u["name"] as? String
            let imageUrl = URL(string: u["profilePic"] as! String)
            self.imgUser.kf.setImage(with: imageUrl, placeholder: #imageLiteral(resourceName: "defaultJudge"), options: [.transition(.fade(0.1))], progressBlock: nil, completionHandler: nil)
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
//MARK: - Table View Methods
extension SideMenuVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DashBoardTableCell", for: indexPath) as! DashBoardTableCell
        cell.imageView?.image = UIImage(named: self.arrImage[indexPath.row])
        cell.textLabel?.text = self.arrName[indexPath.row]
        
//        let view = UIView()
//        view.backgroundColor = Common.s.appColor
//        cell.selectedBackgroundView = view
        return cell
    }
}

extension SideMenuVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        self.sideMenuViewController!.hideMenuViewController()
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "pushController"), object: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
