//
//  DashBoardCollectionCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 15/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class DashBoardCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var imgName: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1).cgColor
//        self.backgroundColor = UIColor.white
    }
    
    func updateCell(name: String, image: String) {
        self.lblName.text  = name
        self.imgName.image = UIImage(named: image)
    }
}
