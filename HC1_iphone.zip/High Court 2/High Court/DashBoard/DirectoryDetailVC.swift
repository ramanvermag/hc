//
//  DirectoryDetailVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import AssetsLibrary
import CoreActionSheetPicker
import MapKit

class DirectoryDetailVC: UIViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var constraintViewheight: NSLayoutConstraint!
    @IBOutlet weak var constraintTableHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintMapHeight: NSLayoutConstraint!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnCamera: UIButton!
    @IBOutlet weak var btnLogout: UIButton!
    @IBOutlet weak var constraintMapView: NSLayoutConstraint!
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var tableView: UITableView!
    let arrIcons = ["designation", "profile-name", "profile", "enrol", "memberNo", "email",  "landline", "mobile", "addResidential", "addCourt", "blood", ""]
    let arrType  = ["DESIGNATION", "NAME",  "PROFILE", "BAR COUNCIL ENROLMENT NO", "BAR ASSOCIATION MEMBERSHIP NO", "EMAIL ID", "LANDLINE NO", "MOBILE NO", "RESIDENTIAL ADDRESS",  "COURT ADDRESS", "BLOOD GROUP", ""]
    var arrName: [Any]  = []
    var textViews: [UITextView] = []
    var bloodGroup: [Any] = []
    var bloodGroupID: [Any] = []
    
    var latLong = CLLocationCoordinate2D()
    var locationBool = false
    var editable: Bool = false
    var cameraBool = Bool()
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.start()
        self.loadData()
    }
    
    func start() {
//        self.constraintTableHeight.constant = self.constraintTableHeight.constant - 70
        self.btnCamera.isUserInteractionEnabled = false
        self.btnCamera.isHidden = true
        
        self.mapView.showsUserLocation = false
        
        self.locationManager.delegate = self
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
//        self.btnLogout.isHidden = true
//        self.constraintMapView.constant = -40
    }
    
    func loadData() {
        var u = NSDictionary()
        if self.arrName.count > 0 {
            u = self.arrName[0] as! NSDictionary
            self.btnEdit.isHidden = true
            self.btnCamera.isHidden = true
        } else {
            self.loadBloodGroup()
            u = ApiData.s.unarchiveData(for: ApiData.s.userDefault.object(forKey: UserDefaultVariables.user) as! Data)
            print("u: ",u)
        }
        
        let detail = Detail(o: u)

        self.arrName.removeAll()
        arrName = [detail.designation, detail.name, detail.profile, detail.enrollment_number, detail.enrollment_number, detail.public_email, detail.landline, detail.mobile, detail.residential_address, detail.court_address, detail.bloodGroup, ""]
        
//        self.textViews[0].text = detail.designation
//        self.textViews[1].text = detail.name
//        self.textViews[2].text = detail.profile
//        self.textViews[3].text = detail.enrollment_number
//        self.textViews[4].text = detail.enrollment_number
//        self.textViews[5].text = detail.public_email
//        self.textViews[6].text = detail.landline
//        self.textViews[7].text = detail.mobile
//        self.textViews[8].text = detail.residential_address
//        self.textViews[9].text = detail.court_address
//        self.textViews[10].text = detail.bloodGroup
//        self.textViews[11].text = ""

        print("arrName = \(arrName)")
        self.lblUser.text = detail.name
        
        let imageUrl = URL(string: detail.profile_pic)
        self.imgUser.kf.setImage(with: imageUrl, placeholder: #imageLiteral(resourceName: "defaultJudge"), options: [.transition(.fade(0.1))], progressBlock: nil, completionHandler: nil)
        Common.s.cornerRadius(img: self.imgUser)
        
        let annotation = MKPointAnnotation()
        var profileLocation = CLLocationCoordinate2DMake(Double(detail.lat1), Double(detail.long1))
        annotation.coordinate = profileLocation
        print(CLLocationCoordinate2DMake(Double(detail.lat1), Double(detail.long1)))
        self.mapView.addAnnotation(annotation)
        
        profileLocation = CLLocationCoordinate2DMake(Double(detail.lat2 + 1.0), Double(detail.long2 + 1.0))
        annotation.coordinate = profileLocation
        print(CLLocationCoordinate2DMake(Double(detail.lat2 + 1.0), Double(detail.long2 + 1.0)))
        self.mapView.addAnnotation(annotation)
        
        let span = MKCoordinateSpanMake(0.4, 0.4)
        let region = MKCoordinateRegion(center: profileLocation, span: span)
        mapView.setRegion(region, animated: true)
        mapView.setCenter(profileLocation, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
//        self.scrollContentSize()
    }
    
    func scrollContentSize() {
        self.constraintTableHeight.constant = self.tableView.frame.height
        let height = self.constraintMapHeight.constant + self.constraintViewheight.constant + self.constraintTableHeight.constant
        self.scrollView.contentSize = CGSize(width: Common.s.screenSize.width, height: height)
    }
    
    func loadBloodGroup() {
        Api.s.post(controller: self, method: Api.s.bloodGroup, param: [:]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    if let lists = result?.value(forKey: "list") as? NSArray {
                        for list in lists {
                            if let group = list as? NSDictionary {
                                self.bloodGroupID.append("\(group.value(forKey: "id")!)")
                                self.bloodGroup.append(group.value(forKey: "name") as! String)
                            }
                        }
                    }
                } else {
                    self.present(Common.s.alertMessage(result?.value(forKey: "error") as! String), animated: true, completion: nil)
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnEditAction(_ sender: UIButton) {
        self.btnCamera.isUserInteractionEnabled = true
        self.btnCamera.isHidden = false
        
        if self.editable == false {
//            self.constraintTableHeight.constant = self.constraintTableHeight.constant + 70
            self.editable = true
            sender.setTitle("Save", for: .normal)
            sender.setImage(UIImage(), for: .normal)
            self.tableView.reloadData()
        } else {
            var valid = Bool()
            
            for txtview in 1..<11 {
                if txtview == 3 || txtview == 4 {
                    continue
                }
                valid = self.validateTextview(sender: self.textViews[txtview], alertText: self.arrType[txtview])
                if valid {
                    return
                }
            }
            
//            if self.locationBool == false {
//                self.navigationController?.present(Common.s.alertMessage("Allow your current location as home address"), animated: true, completion: nil)
//                return
//            }
            
            valid = self.validation()
            
            if valid == false {
                for blood in self.bloodGroup.enumerated() {
                    if blood.element as! String == self.textViews[10].text! {
                        self.textViews[10].text! = self.bloodGroupID[blood.offset] as! String
                    }
                }
//                var param = ["Profile[name]" : self.textViews[1].text!,
//                             "Profile[profile]": self.textViews[2].text!,
//                             "Profile[public_email]" : self.textViews[5].text!,
//                             "Profile[landline]" : self.textViews[6].text!,
//                             "Profile[mobile]" : self.textViews[7].text!,
//                             "Profile[residential_address]" : self.textViews[8].text!,
//                             "Profile[court_address]" : self.textViews[9].text!,
//                             "Profile[blood_group]" : self.textViews[10].text!]
//                    if self.locationBool {
//                        param = ["Profile[name]" : self.textViews[1].text!,
//                                "Profile[profile]": self.textViews[2].text!,
//                                "Profile[public_email]" : self.textViews[5].text!,
//                                "Profile[landline]" : self.textViews[6].text!,
//                                "Profile[mobile]" : self.textViews[7].text!,
//                                "Profile[residential_address]" : self.textViews[8].text!,
//                                "Profile[court_address]" : self.textViews[9].text!,
//                                "Profile[blood_group]" : self.textViews[10].text!,
//                                "Profile[lat1]" : self.latLong.latitude.description,
//                                "Profile[long1]" : self.latLong.longitude.description]
//                    }
                
                var param = ["Profile[name]" : self.arrName[1],
                             "Profile[profile]": self.arrName[2],
                             "Profile[public_email]" : self.arrName[5],
                             "Profile[landline]" : self.arrName[6],
                             "Profile[mobile]" : self.arrName[7],
                             "Profile[residential_address]" : self.arrName[8],
                             "Profile[court_address]" : self.arrName[9],
                             "Profile[blood_group]" : self.arrName[10]]
                if self.locationBool {
                    param = ["Profile[name]" : self.arrName[1],
                             "Profile[profile]": self.arrName[2],
                             "Profile[public_email]" : self.arrName[5],
                             "Profile[landline]" : self.arrName[6],
                             "Profile[mobile]" : self.arrName[7],
                             "Profile[residential_address]" : self.arrName[8],
                             "Profile[court_address]" : self.arrName[9],
                             "Profile[blood_group]" : self.arrName[10],
                             "Profile[lat1]" : self.latLong.latitude.description,
                             "Profile[long1]" : self.latLong.longitude.description]
                }
                
                Api.s.uploadImage(controller: self, filename: self.imageName, param: param as! [String : String], img: self.imgUser.image!, tokenId: "\(ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)!)", completion: { (result) in
                    Common.s.hideActivityIndicator()
                    if result != nil {
                        if result?.value(forKey: "is_success") as! Bool {
                            let data = ApiData.s.archivedData(data: result?.value(forKey: "user") as Any)
                            ApiData.s.userDefault.set(data, forKey: UserDefaultVariables.user)
                            ApiData.s.userDefault.synchronize()
                            KingfisherManager.shared.cache.clearMemoryCache()
                            
                            let u = ApiData.s.unarchiveData(for: ApiData.s.userDefault.object(forKey: UserDefaultVariables.user) as! Data)
                            KingfisherManager.shared.cache.removeImage(forKey: u["profilePic"] as! String)
                            
                            self.arrName.removeAll()
                            self.loadData()
                            self.editable = false
//                            self.constraintTableHeight.constant = self.constraintTableHeight.constant - 70
                            self.tableView.reloadData()
                            self.navigationController?.present(Common.s.alertMessage("Your proile was updated successfully."), animated: true, completion: nil)
                        } else {
                            self.navigationController?.present(Common.s.alertMessage("Your proile wasn't updated successfully. Please try again later!"), animated: true, completion: nil)
                        }
                    } else {
                        self.navigationController?.present(Common.s.alertMessage("Your proile wasn't updated successfully. Please try again later!"), animated: true, completion: nil)
                    }
                })
                
            }
        }
    }
    
    func validation() -> Bool {
        var valid = Bool()
        if self.textViews[5].isKind(of: UITextView.self) {
            valid = false
            if Common.s.isValidEmail(testStr: self.textViews[5].text!) == false {
                self.present(Common.s.alertMessage("Email address seems invalid."), animated: true, completion: nil)
                valid = true
            }
        } else if self.textViews[7].isKind(of: UITextView.self) {
            valid = true
            if self.textViews[7].text.characters.count != 10  {
                self.present(Common.s.alertMessage("Mobile number cannot be more/less than 10 digits."), animated: true, completion: nil)
                valid = true
            }
        }
        return valid
    }
    
    func validateTextview(sender: UITextView, alertText: String) -> Bool {
        if sender.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) == "" {
            sender.becomeFirstResponder()
            self.present(Common.s.alertMessage("\(alertText) cannot be blank."), animated: true, completion: nil)
            return true
        }
        return false
    }
    
    @IBAction func btnLogoutAction(_ sender: UIButton) {
        ApiData.s.userDefault.set(true, forKey: UserDefaultVariables.logout)
        ApiData.s.userDefault.synchronize()
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVCID") as! LoginVC
        self.navigationController?.show(vc, sender: nil)
    }
    
    @IBAction func btnCameraAction(_ sender: UIButton) {
        self.changephoto()
    }
    
    func changephoto() {
        let view: UIAlertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let ok: UIAlertAction = UIAlertAction(title: "Take Photo", style: .default, handler: {(action: UIAlertAction) -> Void in
            //Do some thing here
            if !UIImagePickerController.isSourceTypeAvailable(.camera) {
                let myAlertView: UIAlertView = UIAlertView(title: "No Camera", message: "Sorry, this device has no camera.", delegate: nil, cancelButtonTitle: "OK")
                myAlertView.show()
            }
            else {
                self.takePhoto()
            }
            view.dismiss(animated: true, completion: { _ in })
        })
        let gallery: UIAlertAction = UIAlertAction(title: "Select From Gallery", style: .default, handler: {(action: UIAlertAction) -> Void in
            view.dismiss(animated: true, completion: { _ in })
            self.selectPhoto()
        })
        let cancel: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {(action: UIAlertAction) -> Void in
            view.dismiss(animated: true, completion: { _ in })
        })
        view.addAction(ok)
        view.addAction(gallery)
        view.addAction(cancel)
        self.present(view, animated: true, completion: nil)
    }
    
    func takePhoto() {
        self.cameraBool = true
        let picker = UIImagePickerController()
        picker.delegate = self
//        picker.allowsEditing = true
        picker.sourceType = .camera
        picker.allowsEditing = false
        picker.cameraCaptureMode = .photo
        picker.modalPresentationStyle = .fullScreen
        self.present(picker, animated: true, completion: { _ in })
    }
    
    func selectPhoto() {
        self.cameraBool = false
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        self.present(picker, animated: true, completion: { _ in })
    }
}

extension DirectoryDetailVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.editable == true {
            return 12
        }
        return 11
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DirectoryDetailTableCell", for: indexPath) as! DirectoryDetailTableCell
        cell.imgIcon.image = UIImage(named: self.arrIcons[indexPath.row])
        cell.showCheck(show: true)
        cell.keyboardType(index: indexPath, edit: self.editable)
        cell.txtValue.delegate = self
        
        
        cell.btnCheckbox.titleLabel?.clipsToBounds = true
        cell.btnCheckbox.titleLabel?.adjustsFontSizeToFitWidth = true
        cell.btnCheckbox.addTarget(self, action: #selector(btnCheckboxAction(_:)), for: .touchUpInside)
        cell.lblTitle.text = self.arrType[indexPath.row]
        
        if indexPath.row < 11 {
            self.textViews.append(cell.txtValue)
        }
        let val = self.arrName[indexPath.row]
        if self.editable == false {
    //        let val = self.textViews[indexPath.row].text!
            let textValue = val as! String
            self.textViews[indexPath.row].text = textValue
            print("false indexPath.row: \(indexPath.row) - \(val)")
            cell.txtValue.text = textValue //self.textViews[indexPath.row].text
        } else {
            print("true indexPath.row: \(indexPath.row) - \(val)")
            cell.txtValue.text = val as! String
        }
        return cell
    }
    
    
    func btnCheckboxAction(_ sender: UIButton) {
        UIView.animate(withDuration: 0.34, delay: 0.0, options: .curveEaseInOut, animations: { 
            if sender.image(for: .normal) == CheckBox.checked {
                self.locationBool = false
                sender.setImage(CheckBox.unchecked, for: .normal)
            } else {
                self.locationBool = true
                sender.setImage(CheckBox.checked, for: .normal)
            }
        }, completion: nil)
    }
}
extension DirectoryDetailVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let val = self.arrName[indexPath.row]
        let textValue = val as! String
        var height = 70
        
        if indexPath.row == 12 {
            return CGFloat(height)
        }
        
        height = Int(CGFloat(60.0 + Double(Common.s.getHeight(messageString: textValue))))
        return CGFloat(height)

//        if self.arrType[indexPath.row] == "RESIDENTIAL ADDRESS" || self.arrType[indexPath.row] == "COURT ADDRESS" {
//           height = 90
//        }
//        return CGFloat(height)
    }
}

extension DirectoryDetailVC: UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            self.imgUser.image = pickedImage
            
            if self.cameraBool == true {
                UIImageWriteToSavedPhotosAlbum(pickedImage, nil, nil, nil)
                
                ALAssetsLibrary().writeImage(toSavedPhotosAlbum: pickedImage.cgImage, orientation: ALAssetOrientation(rawValue: pickedImage.imageOrientation.rawValue)!, completionBlock: { (path, err) in
                    print("upload image path - \(path?.absoluteString)")
                    print("path?.pathComponents - \(path?.pathComponents.last)")
                    self.imageName = (path?.pathComponents.last)!
                })
            } else {
                let imageURL = info[UIImagePickerControllerReferenceURL] as! NSURL
                let imageName = imageURL.lastPathComponent
                
                self.imageName = imageName!
                print("imageURL.path - \(imageURL.path)")
            }
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
extension DirectoryDetailVC: UITextViewDelegate {
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        let cell = textView.superview?.superview?.superview as! DirectoryDetailTableCell
        let index = self.tableView.indexPath(for: cell)
        self.arrName[(index?.row)!] = textView.text
        self.textViews[(index?.row)!].text = textView.text!
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        let cell = textView.superview?.superview?.superview as! DirectoryDetailTableCell
        let index = self.tableView.indexPath(for: cell)
        
        if index?.row == 10 {
            textView.resignFirstResponder()
            ActionSheetStringPicker.show(withTitle: "Select Blood Group", rows: self.bloodGroup, initialSelection: 0, doneBlock: { (picker, index, value) in
                print("sender values = \(value)")
                self.textViews[10].text = self.bloodGroupID[index] as! String
                self.arrName[10] = value as! String!
                cell.txtValue.text     = value as! String!
                print("sender bloodGroupID = \(self.bloodGroupID[index])")
                print("sender indexes = \(index)")
                print("sender picker = \(picker)")
                textView.resignFirstResponder()
            }, cancel: { (ActionSheetStringPicker) in
                return
            }, origin: textView)
        }
    }
}

extension DirectoryDetailVC: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
            
            latLong = (manager.location?.coordinate)! //CLLocationCoordinate2D(latitude: 31.278861, longitude: 75.778970)
            
//            let annotation = MKPointAnnotation()
//            
//            annotation.coordinate = latLong
//            
//            self.mapView.addAnnotation(annotation)
//            
//            let span = MKCoordinateSpanMake(0.05, 0.05)
//            let region = MKCoordinateRegion(center: latLong, span: span)
//            mapView.setRegion(region, animated: true)
//            mapView.setCenter(latLong, animated: true)
        }
        else if status == .denied {
            
            let alertController = UIAlertController(title: "Your location services are Disabled", message: "Turn on your Location from the Settings to help us locate you.", preferredStyle: UIAlertControllerStyle.alert)
            
            let closeAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) { (alertAction) -> Void in
            }
            let SettingsAction = UIAlertAction(title: "Settings", style: UIAlertActionStyle.default) { (alertAction) -> Void in
                UIApplication.shared.openURL(NSURL(string: UIApplicationOpenSettingsURLString)! as URL)
            }
            alertController.addAction(closeAction)
            alertController.addAction(SettingsAction)
            present(alertController, animated: true, completion: nil)
        }
    }
}

extension DirectoryDetailVC: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // Don't want to show a custom image if the annotation is the user's location.
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        // Better to make this class property
        let annotationIdentifier = "AnnotationIdentifier"
        
        var annotationView: MKAnnotationView?
        if let dequeuedAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: annotationIdentifier) {
            annotationView = dequeuedAnnotationView
            annotationView?.annotation = annotation
        }
        else {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
//            annotationView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        
        if let annotationView = annotationView {
            // Configure your annotation view here
//            annotationView.canShowCallout = true
            annotationView.image = UIImage(named: "CourtMapIcon")
        }
        
        return annotationView
    }
}
