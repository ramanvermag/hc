//
//  MemberDirectoryVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class MemberDirectoryVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var list = NSMutableArray()
    var load_more = true
    var page_no   = 1
    
    var searchText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Common.s.navColor(sender: self)
        self.tableView.tableFooterView = UIView()
        self.loadMore()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func loadMore() {
        if self.load_more {
            self.loadMembers(page: self.page_no)
        }
    }
    
    func loadMembers(page: Int) {
        var param = ["":""]
        if self.searchText != "" {
            param = ["ProfileSearch[name]" : self.searchText]
        }
        Api.s.post(controller: self, method: Api.s.memberDirectory + "?page=\(page)", param: param as NSDictionary) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    if self.searchText != "" {
                        if page == 1 {
                            self.list.removeAllObjects()
                        }
                    }
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    
//                    self.list = result?.value(forKey: "list") as! NSArray
                    self.tableView.reloadData()
                } else {
                    
                }
            } else {
                
            }
            if let pagination = result?.value(forKey: "pagination") {
                if let load_more = (pagination as! NSDictionary).value(forKey: "load_more") {
                    self.load_more = load_more as! Bool
                    self.page_no = self.page_no + 1
                }
//                if let page_no = (pagination as! NSDictionary).value(forKey: "page_no") {
//                    self.page_no = page_no as! Int
//                }
            }
        }
    }
}

extension MemberDirectoryVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemberDirectoryTableCell", for: indexPath) as! MemberDirectoryTableCell
        Common.s.accessoryView(table: cell) 
        cell.updateData(object: self.list[indexPath.row] as! NSDictionary)
        cell.btnContact.addTarget(self, action: #selector(btnCallAction(_:)), for: .touchUpInside)
        cell.btnContactSecond.addTarget(self, action: #selector(btnCallAction(_:)), for: .touchUpInside)
        
        if indexPath.row == self.list.count - 1 {
            self.loadMore()
        }
        return cell
    }
    
    func btnCallAction(_ sender: UIButton) {
        ApiData.s.btnCall(controler: self, sender)
    }
    
}

extension MemberDirectoryVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DirectoryDetailVCID") as! DirectoryDetailVC
        self.navigationController?.show(vc, sender: nil)
        vc.arrName = [self.list[indexPath.row]]
    }
}

extension MemberDirectoryVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        self.page_no = 1
        self.load_more = true
        self.loadMore()
    }
}
