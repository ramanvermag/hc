//
//  MemberDirectoryTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class MemberDirectoryTableCell: UITableViewCell {

    @IBOutlet weak var imgMember: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnContact: UIButton!
    @IBOutlet weak var btnContactSecond: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        Common.s.cornerRadius(img: imgMember)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func updateData(object: NSDictionary) {
        let detail = Detail(o: object)

        lblName.text = detail.name
        btnContact.setTitle(" " + detail.landline, for: .normal)
        btnContactSecond.setTitle(" " + detail.mobile, for: .normal)
        ApiData.s.setImage(image: imgMember, img: detail.profile_pic)
        
//        let member = Members.member(o: object)
//
//        lblName.text = member.name
//        btnContact.setTitle(" " + member.contactSecond, for: .normal)
//        btnContactSecond.setTitle(" " + member.contact, for: .normal)
//        ApiData.s.setImage(image: imgMember, img: member.imgUrl)
    }
}
