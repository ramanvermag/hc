//
//  DirectoryDetailTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import CoreLocation

struct CheckBox {
    static let checked   = #imageLiteral(resourceName: "checkbox-select")
    static let unchecked = #imageLiteral(resourceName: "checkbox-unselect")
}

class DirectoryDetailTableCell: UITableViewCell {

    @IBOutlet weak var imgIcon: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var txtValue: UITextView!
    @IBOutlet weak var viewCheckbox: UIView!
    @IBOutlet weak var btnCheckbox: UIButton!
    
    let txtFieldBackColor = UIColor(red: 227/255, green: 223/255, blue: 212/255, alpha: 1)
    let txtFieldBorderColor = UIColor(red: 190/255, green: 188/255, blue: 76/255, alpha: 1)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        txtValue.layer.borderWidth = 0
        txtValue.scrollRangeToVisible(NSMakeRange(0, 0))
        txtValue.setContentOffset(CGPoint.zero, animated: false)
    }
    
//    override func prepareForReuse() {
//        super.prepareForReuse()
//        txtValue.text = ""
//    }
    
    func keyboardType(index: IndexPath, edit: Bool) {
        switch index.row {
        case 5:
            self.txtValue.keyboardType = .emailAddress
            break
        case 6:
            self.txtValue.keyboardType = .phonePad
            break
        case 7:
            self.txtValue.keyboardType = .phonePad
            break
        case 11:
            self.showCheck(show: false)
            break
        default:
            self.showCheck(show: true)
            break
        }
        
        if edit == true {
//            if index.row != 2 && index.row != 3 {
            if index.row > 4 || index.row == 1 || index.row == 2 {
                txtValue.isEditable = true
                
                txtValue.layer.borderWidth = 1
                txtValue.backgroundColor = self.txtFieldBackColor
            } else {
                txtValue.isEditable = false
                txtValue.layer.borderWidth = 0
                txtValue.backgroundColor = UIColor.white
            }
        } else {
            txtValue.isEditable = false
            txtValue.layer.borderWidth = 0
            txtValue.backgroundColor = UIColor.white
        }
        txtValue.layer.borderColor = self.txtFieldBorderColor.cgColor
    }
    
    func showCheck(show: Bool) {
        self.viewCheckbox.isHidden = show
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
//    
//    @IBAction func btnCheckboxAction(_ sender: UIButton) {
//        
//    }
}

struct Detail {
    var dict = NSDictionary()
    var defaultLocation = CLLocationCoordinate2D(latitude: 30.7573054, longitude: 76.8043686)
    init(o: NSDictionary) {
        dict = o
    }
    
    var bloodGroup: String {
        guard let blood = dict.value(forKey: "bloodGroup") else { return "" }
        if let b = blood as? NSDictionary {
            guard let name = b.value(forKey: "name") else { return "" }
            let returnName = Roster().getSet(val: name)
            if returnName == "" {
                guard let blood_group = dict.value(forKey: "blood_group") else { return "" }
                return Roster().getSet(val: blood_group)
            } else {
                return returnName
            }
        } else {
            guard let blood_group = dict.value(forKey: "blood_group") else { return "" }
            return Roster().getSet(val: blood_group)
        }
    }
    
    var court_address: String {
        guard let court = dict.value(forKey: "court_address") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var designation: String {
        guard let court = dict.value(forKey: "designation") else { return "" }
        if let b = court as? NSDictionary {
            guard let name = b.value(forKey: "name") else { return "" }
            return Roster().getSet(val: name)
        }
        return ""
    }
    
    var enrollment_number: String {
        guard let court = dict.value(forKey: "enrollment_number") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var landline: String {
        guard let court = dict.value(forKey: "landline") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var mobile: String {
        guard let court = dict.value(forKey: "mobile") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var name: String {
        guard let court = dict.value(forKey: "name") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var profile: String {
        guard let court = dict.value(forKey: "profile") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var profile_pic: String {
        guard let court = dict.value(forKey: "profilePic") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var public_email: String {
        guard let court = dict.value(forKey: "public_email") else { return "" }
        return Roster().getSet(val: court)
    }
    var residential_address: String {
        guard let court = dict.value(forKey: "residential_address") else { return "" }
        return Roster().getSet(val: court)
    }
    
    var lat1: Double {
        guard let court = dict.value(forKey: "lat1") else { return defaultLocation.latitude }
        print(type(of: court))
        if Roster().getSet(val: court) != "" {
            return Double(Roster().getSet(val: court))!
        } else {
            return defaultLocation.latitude
        }
    }
    var lat2: Double {
        guard let court = dict.value(forKey: "lat2") else { return defaultLocation.latitude }
        if Roster().getSet(val: court) != "" {
            return Double(Roster().getSet(val: court))!
        } else {
            return defaultLocation.latitude
        }
    }
    var long1: Double {
        guard let court = dict.value(forKey: "long1") else { return defaultLocation.longitude }
        if Roster().getSet(val: court) != "" {
            return Double(Roster().getSet(val: court))!
        } else {
            return defaultLocation.longitude
        }
    }
    var long2: Double {
        guard let court = dict.value(forKey: "long2") else { return defaultLocation.longitude }
        if Roster().getSet(val: court) != "" {
            return Double(Roster().getSet(val: court))!
        } else {
            return defaultLocation.longitude
        }
    }
}
