//
//  ViewController.swift
//  High Court
//
//  Created by Karun Aggarwal on 15/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var viewBanner: ImageSlideshow!
    @IBOutlet weak var constraintBannerHeight: NSLayoutConstraint!
    @IBOutlet weak var btnBannerClose: UIButton!
    
    let arrName  = ["EXECUTIVE", "MEMBER'S DIRECTORY", "HON'BLE JUDGES", "NOTIFICATIONS", "DISPLAY BOARD", "CALENDAR", "ROSTER", "CASE LAW", "ACHIEVEMENTS"]
    let arrImage = ["Executive", "Member", "Honrable", "notification", "Display", "Calendar", "Roaster", "CaseLaw", "achievement"]
    var arrCount: [Any] = []
    
    var sideMenu = SideMenuVC()
    var tapGesture = UITapGestureRecognizer()
    var bannerlist = NSMutableSet()
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        sideMenu = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuVCID") as! SideMenuVC
        sideMenu.view.frame = CGRect(x: -Common.s.screenSize.width, y: 0, width: Common.s.screenSize.width * 0.80, height: Common.s.screenSize.height)
        self.view.addSubview(sideMenu.view)
        
        Common.s.tableSeperator(tableView: self.tableView)
        self.startNotification()

        tableView.dataSource = self
        tableView.delegate = self
        
        tapGesture.addTarget(self, action: #selector(self.tapAction(sender:)))
        tapGesture.numberOfTapsRequired = 1
        tapGesture.numberOfTouchesRequired = 1
        
        self.loadBanners()
        timer = Timer.scheduledTimer(timeInterval: (60 * 5), target: self, selector: #selector(self.notificationCount), userInfo: nil, repeats: true)
    }
    
    func loadBanners() {
        self.viewBanner.bringSubview(toFront: self.btnBannerClose)
        self.constraintBannerHeight.constant = 80
        Api.s.post(controller: self, method: Api.s.banner, param: ["":""]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    self.viewBanner.slideshowInterval = self.bannerTime(val: result?.value(forKey: "banner_timing"))
                    let lists = result?.value(forKey: "list") as! NSArray
                    for list in lists {
                        let banner = BannerList(o: list as! NSDictionary)
                        self.bannerlist.add(SDWebImageSource(urlString: banner.image_path)!)
                    }
                    self.viewBanner.pageControl.isHidden = true
                    self.viewBanner.setImageInputs(self.bannerlist.allObjects as! [InputSource])
                } else {
                    
                }
            } else {
                
            }
            self.notificationCount()
        }
    }
    
    func bannerTime(val: Any?) -> Double {
        guard let banner_timing = val else { return 2.0 }
        return banner_timing as! Double
    }
    
    @IBAction func btnBannerCloseAction(_ sender:   UIButton) {
        self.constraintBannerHeight.constant = 0
    }
    
    func tapAction(sender: UITapGestureRecognizer) {
        UIView.animate(withDuration: 0.34, delay: 0.1, options: .curveEaseInOut, animations: {
            self.sideMenu.view.frame.origin.x = -Common.s.screenSize.width
            self.tableView.isUserInteractionEnabled = true
            self.tableView.removeGestureRecognizer(self.tapGesture)
        }, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
//        self.navigationController?.navigationBar.barTintColor = UIColor.white
        Common.s.navColor(sender: self)
        
        self.sideMenu.updateSideMenu()
        timer.fire()
        if notifyRead["notify"] == true || notifyRead["caselaw"] == true {
            self.tableView.reloadData()
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        timer.invalidate()
    }
    
    func notificationCount() {
         let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
        Api.s.postHeader(controller: self, method: Api.s.notificationCount, param: ["": ""], header: ["highcourt-header-token" : "\(token!)"], completion: { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    let notifycount = NotificationCount(o: result!)
                    self.arrCount = [notifycount.un_read_count, notifycount.case_law_count]
                    self.tableView.reloadData()
                }
            }
        })
    }
    
    @IBAction func menuBtnAction(_ sender: UIBarButtonItem) {
//        presentLeftMenuViewController(sender)
        UIView.animate(withDuration: 0.34, delay: 0.1, options: .curveEaseInOut, animations: {
            if self.sideMenu.view.frame.origin.x == -Common.s.screenSize.width {
                self.sideMenu.view.frame.origin.x = 0
                self.view.bringSubview(toFront: self.sideMenu.view)
//                self.tableView.isUserInteractionEnabled = false
                self.tableView.addGestureRecognizer(self.tapGesture)
                
            } else {
                self.sideMenu.view.frame.origin.x = -Common.s.screenSize.width
                self.tableView.isUserInteractionEnabled = true
                self.tableView.removeGestureRecognizer(self.tapGesture)
            }
//            self.navigationController?.navigationBar.frame.origin.x = Common.s.screenSize.width * 0.80
        }, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func startNotification() {
        NotificationCenter.default.addObserver(self, selector: #selector(pushController(obj:)), name: NSNotification.Name(rawValue: "pushController"), object: nil)
    }
    
    func pushController(obj: NSNotification) {
        switch obj.object as! Int {
        case 0:
        /// My Profile
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DirectoryDetailVCID") as! DirectoryDetailVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 1:
        /// Pay My Dues
//            let vc = self.storyboard?.instantiateViewController(withIdentifier: "PaymentVCID") as! PaymentVC
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CommingSoonVCID") as! CommingSoonVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 2:
        /// Change Password
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePassVCID") as! ChangePassVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
        /// Logout
            ApiData.s.userDefault.set(true, forKey: UserDefaultVariables.logout)
            ApiData.s.userDefault.synchronize()
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVCID") as! LoginVC
            self.navigationController?.show(vc, sender: nil)
            break
        default:
            break
        }
    }
}

//MARK: - Table View Methods
extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DashBoardTableCell", for: indexPath) as! DashBoardTableCell
        
        cell.imgIcon.image = UIImage(named: self.arrImage[indexPath.row])
        cell.lblOptionName.text = self.arrName[indexPath.row]
        
        var boool = Bool()
        var valNumber = ""
        switch indexPath.row {
        case 3:
    /// Notification
            valNumber = self.arrCount.count > 0 ? self.arrCount[0] as! String : ""
            boool = false
            if notifyRead["notify"] == true {
                boool = true
                valNumber = ""
            }
            break
        case 7:
    /// Case law
            valNumber = self.arrCount.count > 0 ? self.arrCount[1] as! String : ""
            boool = false
            if notifyRead["caselaw"] == true {
                boool = true
                valNumber = ""
            }
            break
        default:
            boool = true
            break
        }
        cell.showNumber(show: boool, text: valNumber)
        
        Common.s.accessoryView(table: cell)
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return self.tableView.frame.height / CGFloat(self.arrName.count)
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        UIView.animate(withDuration: 0.34, delay: 0.1, options: .curveEaseInOut, animations: { 
//            if self.sideMenu.view.frame.origin.x == 0 {
//                self.sideMenu.view.frame.origin.x = -Common.s.screenSize.width
//                return
//            }
//        }, completion: nil)
        
        switch indexPath.row {
        case 0:
        /// ExecutiveCommetteVC
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ExecutiveCommetteVCID") as! ExecutiveCommetteVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 1:
        /// Member's Directory
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "MemberDirectoryVCID") as! MemberDirectoryVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 2:
        /// Hon'ble Judges
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "JudgeVCID") as! JudgeVC //CommingSoonVC //
//            vc.webUrl = "http://highcourtchd.gov.in/?trs=chief"
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
        /// Notifications
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "NotificationTableVCID") as! NotificationTableVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
        /// Display Board
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CommingSoonVCID") as! CommingSoonVC //HolidayVC
            vc.webUrl = "https://phhc.gov.in/display_board_full_width.php"
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 5:
        /// Calnedar
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "HolidayVCID") as! HolidayVC //CommingSoonVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 6:
        /// Roster
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CommingSoonVCID") as! CommingSoonVC //RoasterVC //
//            vc.webUrl = "http://highcourtchd.gov.in/?trs=roster"
            vc.webUrl = "http://164.100.58.11/?trs=roster"
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 7:
        /// Case law
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CaseLawTableVCID") as! CaseLawTableVC //CommingSoonVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 8:
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AchievementVCID") as! AchievementVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 9:
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CommingSoonVCID") as! CommingSoonVC
            self.navigationController?.pushViewController(vc, animated: true)
            break
        default:
            break
        }
    }
}
