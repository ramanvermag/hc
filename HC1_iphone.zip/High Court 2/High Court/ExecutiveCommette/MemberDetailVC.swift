//
//  MemberDetailVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class MemberDetailVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var imgMember: UIImageView!
    
    fileprivate let tableCell = "memberDetailCell"
    
    let arrIcons = ["designation", "mobile", "landline", "addResidential", "" , "email", "addCourt"]
    let arrType  = ["DESIGNATION", "MOBILE NO.", "LANDLINE NO", "RESIDENTIAL ADDRESS 1", "RESIDENTIAL ADDRESS 2", "EMAIL ID", "COURT ADDRESS"]
    let arrName  = ["President", "94177-59300, 94177-59300", "1651417", "3018, Sector 28-D, Chd.", "3018, Sector 28-D, Chd.", "harpreeetbrar@gmail.com", "Room no 16, New Brar Complex, High Court Chandigarh."]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}

extension MemberDetailVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: tableCell, for: indexPath) as! MemberDetailCell
        cell.imgIcon.image = UIImage(named: self.arrIcons[indexPath.row])
        cell.lblType.text  = self.arrType[indexPath.row]
        cell.lblValue.text = self.arrType[indexPath.row]
        cell.lblValue.text = self.arrName[indexPath.row]
        return cell
    }
    
    
}
