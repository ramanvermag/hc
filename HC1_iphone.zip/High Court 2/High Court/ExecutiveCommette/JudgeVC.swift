//
//  JudgeVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 19/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var list = NSMutableArray()
    var load_more = true
    var page_no   = 1
    
    var searchText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Common.s.navColor(sender: self)
        Common.s.tableSeperator(tableView: self.tableView)
        
        self.loadMore()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    func loadMore() {
        if self.load_more {
            self.loadMembers(page: self.page_no)
        }
    }
    
    func loadMembers(page: Int) {
        var param = ["":""]
        if self.searchText != "" {
            param = ["JudgesSearch[name]" : self.searchText]
        }
        Api.s.post(controller: self, method: Api.s.judgeList + "?page=\(page)", param: param as NSDictionary) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    if self.searchText != "" {
                        if page == 1 {
                            self.list.removeAllObjects()
                        }
                    }
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    self.tableView.reloadData()
                } else {
                    
                }
            } else {
                
            }
            if let pagination = result?.value(forKey: "pagination") {
                if let load_more = (pagination as! NSDictionary).value(forKey: "load_more") {
                    self.load_more = load_more as! Bool
                    self.page_no = self.page_no + 1
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
extension JudgeVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JudgeTableCell", for: indexPath) as! JudgeTableCell
        
        cell.updateData(object: self.list[indexPath.row] as! NSDictionary)
        
        Common.s.accessoryView(table: cell)
        
        if indexPath.row == self.list.count - 1 {
            self.loadMore()
        }
        
        return cell
    }
}
extension JudgeVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "JudgeDetailVCID") as! JudgeDetailVC
        vc.judgeDetail = self.list[indexPath.row] as! NSDictionary
        self.navigationController?.show(vc, sender: nil)
    }
}

extension JudgeVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        if searchText.characters.count == 0 {
            self.list.removeAllObjects()
            self.searchBar.resignFirstResponder()
            self.page_no = 1
            self.load_more = true
            self.loadMore()
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        self.page_no = 1
        self.load_more = true
        self.loadMore()
    }
}
