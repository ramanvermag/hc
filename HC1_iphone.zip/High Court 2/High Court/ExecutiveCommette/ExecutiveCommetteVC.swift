//
//  ExecutiveCommetteVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 17/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ExecutiveCommetteVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    fileprivate let tableCell = "executiveCell"
    var list = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Common.s.navColor(sender: self)
        tableView.register(UINib(nibName: "ExecutiveCommetteCell", bundle: nil), forCellReuseIdentifier: tableCell)
        
        Api.s.post(controller: self, method: Api.s.executive, param: ["":""]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    self.list = result?.value(forKey: "list") as! NSArray
                    self.tableView.reloadData()
                } else {
                    self.present(Common.s.alertMessage(result?.value(forKey: "error") as! String), animated: true, completion: nil)
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

extension ExecutiveCommetteVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: tableCell, for: indexPath) as! ExecutiveCommetteCell
        Common.s.accessoryView(table: cell)
        cell.updateData(for: self.list[indexPath.row] as! NSDictionary)
        cell.btnPhone.addTarget(self, action: #selector(self.btnCallAction(_:)), for: .touchUpInside)
        return cell
    }
    
    func btnCallAction(_ sender: UIButton) {
        ApiData.s.btnCall(controler: self, sender)
    }
}

extension ExecutiveCommetteVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DirectoryDetailVCID") as! DirectoryDetailVC
        self.navigationController?.show(vc, sender: nil)
        vc.arrName = [self.list[indexPath.row]]
    }
}
