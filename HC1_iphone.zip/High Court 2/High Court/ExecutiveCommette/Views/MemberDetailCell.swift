//
//  MemberDetailCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class MemberDetailCell: UITableViewCell {

    @IBOutlet weak var imgIcon: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lblValue.sizeToFit()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
