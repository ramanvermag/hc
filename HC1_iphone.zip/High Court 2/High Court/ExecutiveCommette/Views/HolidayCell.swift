//
//  HolidayCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class HolidayCell: UITableViewCell {
    
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblHolidayName: UILabel!
    @IBOutlet weak var lblHolidayType: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func updateData(object: NSDictionary) {
        let holiday = Holiday(o: object)
        lblDate.text = holiday.date
        lblHolidayName.text = holiday.title
        lblHolidayType.text = holiday.highcourts
        
        print("lblHolidayType: \(holiday.highcourts)")
    }
}

struct Holiday {
    var dict = NSDictionary()
    
    init(o: NSDictionary) {
        dict = o
    }
    
    var title: String {
        return Roster().getSet(val: dict.value(forKey: "title"))
    }
    
    var simpleDate: String {
        return Roster().getSet(val: dict.value(forKey: "date"))
    }
    
    var date: String {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd"
        
        let date = dateFormat.date(from: Roster().getSet(val: dict.value(forKey: "date")))
        dateFormat.dateFormat = "d MMM"
        
        return dateFormat.string(from: date!)
    }
    
    var highcourts: String {
        var name = ""
        guard let judge = dict.value(forKey: "highcourts") else { return "" }
        for n in (judge as! NSArray) {
            let val = Roster().getSet(val: (n as! NSDictionary).value(forKey: "name"))
            name = name == "" ? val : name + "\n" + val
        }
        return name
    }
}
