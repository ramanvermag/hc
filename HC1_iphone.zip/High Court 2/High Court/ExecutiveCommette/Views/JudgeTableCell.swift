//
//  JudgeTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 20/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeTableCell: UITableViewCell {

    @IBOutlet weak var lblJudge: UILabel!
    @IBOutlet weak var lblRoomNo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

        self.sendSubview(toBack: self.textLabel!)
        lblRoomNo.clipsToBounds = true
        lblRoomNo.layer.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func updateData(object: NSDictionary) {
        let j = Judge(o: object)
        
//        self.textLabel?.numberOfLines = 0
//        self.textLabel?.text
        self.lblJudge.text  = j.name
        self.lblRoomNo.text = j.court_room
    }
}

struct Judge {
    var name: String = ""
    var court_room: String = ""
    var landline: String = ""
    var ext_no: String = ""
    var address: String = ""
    var dob: String = ""
    var date_of_appointment: String = ""
    var date_of_retirement: String = ""
    var bio_graphy: String = ""
    var gender: String = ""
    var imgJudge: String = ""
    
    init() {
    }
    
    init(o: AnyObject) {
        self.judgeDetail(o: o)
    }
    
    func convertString(a: AnyObject) -> String {
        return (a as? String) != nil ? a as! String : ""
    }
    
    public mutating func judgeDetail(o: AnyObject) {
        let dict = o as? [String: AnyObject]
        if let name = dict?["name"] {
            self.name = convertString(a: name)
            if let gender = ((dict?["gender"])) {
                self.gender = convertString(a: gender)
                if self.gender == "1" {
                    self.name = "Hon'ble Mr. Justice\n\(self.name)"
                } else {
                    self.name = "Hon'ble Ms. Justice\n\(self.name)"
                }
            }
        }
        
        if let court_room = ((dict?["court_room"])) {
            self.court_room = convertString(a: court_room)
        }
        
        if let landline = ((dict?["landline"])) {
            self.landline = convertString(a: landline)
        }
        
        if let ext_no = ((dict?["ext_no"])) {
            self.ext_no = convertString(a: ext_no)
        }
        
        if let address = ((dict?["address"])) {
            self.address = convertString(a: address)
        }
        
        if let dob = ((dict?["dob"])) {
            self.dob = convertString(a: dob)
        }
        
        if let date_of_appointment = dict?["date_of_appointment"] {
            self.date_of_appointment = convertString(a: date_of_appointment)
        }
        
        if let date_of_retirement = ((dict?["date_of_retirement"])) {
            self.date_of_retirement = convertString(a: date_of_retirement)
        }
        
        if let bio_graphy = ((dict?["bio_graphy"])) {
            self.bio_graphy = convertString(a: bio_graphy)
        }
        
        if let imgJudge = ((dict?["image_src"])) {
            self.imgJudge = convertString(a: imgJudge)
        }
    }
}
