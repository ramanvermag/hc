//
//  HolidayVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class HolidayVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calendarView: CVCalendarView!
    @IBOutlet weak var calendarMenu: CVCalendarMenuView!
    @IBOutlet weak var monthLabel: UILabel!
    
    fileprivate let tableCell = "HolidayCell"
    
    var list = NSMutableArray()
    var load_more = true
    var page_no   = 1
    
    var animationFinished = true
    var currentCalendar: Calendar?
    var selectedMonthYear = ""
    
    override func awakeFromNib() {
        let timeZoneBias = 480 // (UTC+08:00)
        currentCalendar = Calendar.init(identifier: .gregorian)
        if let timeZone = TimeZone.init(secondsFromGMT: -timeZoneBias * 60) {
            currentCalendar?.timeZone = timeZone
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
      //self.calendarView.appearance.dayLabelWeekdaySelectedBackgroundColor = Common.s.appColor
        //self.calendarView.appearance.dayLabelPresentWeekdayTextColor = Common.s.appColor
      //self.calendarView.appearance.dayLabelWeekdaySelectedBackgroundColor = Common.s.appColor
        Common.s.tableSeperator(tableView: self.tableView)
        calendarView.calendarAppearanceDelegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let currentCalendar = currentCalendar {
            monthLabel.text = CVDate(date: Date(), calendar: currentCalendar).globalDescription
            self.selectedMonthYear = monthLabel.text!
        }
        self.loadMore()
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        calendarMenu.commitMenuViewUpdate()
        calendarView.commitCalendarViewUpdate()
    }
    
    func getDateFormat(date: String) -> String {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "MM, yyyy"
        
        let datee = dateFormat.date(from: date)
        dateFormat.dateFormat = "yyyy-MM"
        print("updatedMonthLabel label: \(dateFormat.string(from: datee!))")
        return dateFormat.string(from: datee!)
    }
    
    func loadMore() {
        if self.load_more {
            self.loadMembers(page: self.page_no, dateParam: self.getDateFormat(date: self.selectedMonthYear))
        }
    }
    
    func loadMembers(page: Int, dateParam: String) {
        let parameter = ["HolidaysSearch[date]":dateParam]
        Api.s.post(controller: self, method: Api.s.holiday + "?page=\(page)", param: parameter as NSDictionary) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    self.list.removeAllObjects()
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    self.calendarView.contentController.refreshPresentedMonth()
                    
                    self.tableView.reloadData()
                } else {
                    
                }
            } else {
                
            }
            if let pagination = result?.value(forKey: "pagination") {
                if let load_more = (pagination as! NSDictionary).value(forKey: "load_more") {
                    self.load_more = load_more as! Bool
                    self.page_no = self.page_no + 1
                }
                
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnPreviousAction(_ sender: UIButton) {
        self.calendarView.loadPreviousView()
    }
    
    @IBAction func btnNextAction(_ sender: UIButton) {
        self.calendarView.loadNextView()
    }
    
}

extension HolidayVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: tableCell, for: indexPath) as! HolidayCell
        cell.backgroundColor = UIColor(red: 247/255, green: 247/255, blue: 247/255, alpha: 1)
        
        cell.updateData(object: list[indexPath.row] as! NSDictionary)
        return cell
    }
}

extension HolidayVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let holiday = Holiday(o: self.list[indexPath.row] as! NSDictionary)
        let courts = Common.s.getHeight(messageString: holiday.highcourts)
        print("court: \(courts)")
        return courts + 45
    }
}

extension HolidayVC: CVCalendarViewDelegate, CVCalendarMenuViewDelegate {
    func presentationMode() -> CalendarMode {
        return .monthView
    }
    
    func firstWeekday() -> Weekday {
        return .monday
    }
    
    //func dayOfWeekTextColor() -> UIColor {
      //  return UIColor.red
    //}
    
    func weekdaySymbolType() -> WeekdaySymbolType {
        return .short
    }
    
    func shouldShowWeekdaysOut() -> Bool {
        return true
    }
    
    func shouldSelectDayView(_ dayView: DayView) -> Bool {
        return false
    }
    
    //func topMarker(shouldDisplayOnDayView dayView: DayView) -> Bool {
//        return true
//    }
    
//    func topMarkerColor() -> UIColor {
//        return Common.s.appColor
//    }
    
    func dotMarker(shouldShowOnDayView dayView: DayView) -> Bool {
    /// Saturday Sunday in AppColor
        if dayView.weekdayIndex == 5 || dayView.weekdayIndex == 6 {
            dayView.weekView.tintColor = Common.s.appColor
        }
        if dayView.date.weekDay() == CVCalendarWeekday.saturday  || dayView.date.weekDay() == CVCalendarWeekday.sunday {
            dayView.dayLabel.textColor = Common.s.appColor
        }
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        let date2 = dateformatter.string(from: dayView.date.convertedDate()!)
        for l in list.enumerated() {
            let holiday = Holiday(o: l.element as! NSDictionary)
            let dt = holiday.simpleDate
            
            if dt == date2 {
                return true
            }
        }
        return false
    }
    
    func dotMarker(colorOnDayView dayView: DayView) -> [UIColor] {
        return [UIColor.red]
    }
    
    func dotMarker(moveOffsetOnDayView dayView: DayView) -> CGFloat {
        return dayView.bounds.midY - 5
    }
    
    func presentedDateUpdated(_ date: CVDate) {
        if monthLabel.text != date.globalDescription && self.animationFinished {
            let updatedMonthLabel = UILabel()
            updatedMonthLabel.textColor = monthLabel.textColor
            updatedMonthLabel.font = monthLabel.font
            updatedMonthLabel.textAlignment = .center
            updatedMonthLabel.text = date.globalDescription
            updatedMonthLabel.sizeToFit()
            updatedMonthLabel.alpha = 0
            updatedMonthLabel.center = self.monthLabel.center
            
            let offset = CGFloat(48)
            updatedMonthLabel.transform = CGAffineTransform(translationX: 0, y: offset)
            updatedMonthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
            
            UIView.animate(withDuration: 0.35, delay: 0, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.animationFinished = false
                self.monthLabel.transform = CGAffineTransform(translationX: 0, y: -offset)
                self.monthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
                self.monthLabel.alpha = 0
                
                updatedMonthLabel.alpha = 1
                updatedMonthLabel.transform = CGAffineTransform.identity
                
            }) { _ in
                
                self.animationFinished = true
                self.monthLabel.frame = updatedMonthLabel.frame
                self.monthLabel.text = updatedMonthLabel.text
                self.monthLabel.transform = CGAffineTransform.identity
                self.monthLabel.alpha = 1
                updatedMonthLabel.removeFromSuperview()
            }
    /// Update Month Label and reload table view
            self.selectedMonthYear = updatedMonthLabel.text!
            self.loadMembers(page: self.page_no, dateParam: self.getDateFormat(date: self.selectedMonthYear))
            
            self.view.insertSubview(updatedMonthLabel, aboveSubview: self.monthLabel)
        }
    }
}

extension HolidayVC: CVCalendarViewAppearanceDelegate {
    func dayOfWeekTextColor() -> UIColor {
        return UIColor.black
    }
    
    func dayLabelPresentWeekdaySelectedBackgroundColor() -> UIColor {
        return Common.s.appColor
    }
    
    func dayLabelWeekdayHighlightedBackgroundColor() -> UIColor {
        return Common.s.appColor
    }
    
    func dayLabelWeekdayInTextColor() -> UIColor {
        return Common.s.appColor
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        return Common.s.appColor
    }
    
    func dayLabelPresentWeekdayTextColor() -> UIColor {
        return Common.s.appColor
    }
}
