//
//  ExecutiveCommetteCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 17/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ExecutiveCommetteCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var btnPhone: UIButton!
    @IBOutlet weak var imgUser: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateData(for data: NSDictionary) {
        if let name = data.value(forKey: "name") {
            self.lblName.text = name as? String
        }
        if let profile = data.value(forKey: "profile") {
            self.lblDesignation.text = profile as? String
        }
        if let mobile = data.value(forKey: "mobile") {
            self.btnPhone.setTitle(" \(mobile)", for: .normal)
        }
        if let profilePic = data.value(forKey: "profilePic") {
            let imageUrl = URL(string: profilePic as! String)
            self.imgUser.kf.setImage(with: imageUrl, placeholder: #imageLiteral(resourceName: "defaultJudge"), options: [.transition(.fade(0.1))], progressBlock: nil, completionHandler: nil)
        }
    }
}
