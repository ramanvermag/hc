//
//  NotificationTableVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class NotificationTableVC: UITableViewController {

    let cellIdentifier = "NotificationTableCell"
    
    var list = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationIDs.removeAllObjects()
        
        self.tableView.register(UINib(nibName: cellIdentifier, bundle: nil), forCellReuseIdentifier: cellIdentifier)
        self.loadNotify()
    }

    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        print("\n\nselected array ids - \(notificationIDs)")
        let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
        print(token.debugDescription)
        Api.s.postHeader(controller: self, method: Api.s.notificationRead, param: ["Notification[notification_id]": notificationIDs], header: ["highcourt-header-token" : "\(token!)"], completion: { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    notifyRead["notify"] = true
                    _ = self.navigationController?.popViewController(animated: true)
                } else {
                    _ = self.navigationController?.popViewController(animated: true)
                }
            } else {
                _ = self.navigationController?.popViewController(animated: true)
            }
        })
    }
    
    func loadNotify() {
        let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
        Api.s.postHeader(controller: self, method: Api.s.notification, param: ["":""], header: ["highcourt-header-token" : "\(token!)"]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.list.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! NotificationTableCell
        
        cell.updateData(object: self.list[indexPath.row] as! NSDictionary)
        cell.btnDownload.addTarget(self, action: #selector(btnDownloadAction(_:)), for: .touchUpInside)
        cell.btnDownload.tag = indexPath.row

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let n = Notify.notify(o: self.list[indexPath.row] as! NSDictionary)
        var height = CGFloat()
        height = heightWithConstrainedWidth(text: n.description) + CGFloat(90)
        return height
    }
    
    func heightWithConstrainedWidth( text: String) -> CGFloat {
        let constraintRect = CGSize(width: Common.s.screenSize.width - 32, height: CGFloat.greatestFiniteMagnitude)
        
        let boundingBox = (text as NSString).boundingRect(with: constraintRect, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 16)], context: nil)
        
        return boundingBox.height
    }
    
    func btnDownloadAction(_ sender: UIButton) {
        let n = Notify.notify(o: self.list[sender.tag] as! NSDictionary)
        guard n.notification_src != "" else {
            return
        }
        print("btton tag: \(n.notification_src)")
        var uri = n.notification_src
        if !uri.contains("http") {
            uri = "http://" + uri
        }
        let url = URL(string: uri)
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url!, options: [ : ], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url!)
        }
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
