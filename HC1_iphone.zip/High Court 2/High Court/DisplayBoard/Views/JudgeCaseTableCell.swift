//
//  JudgeCaseTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 03/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeCaseTableCell: UITableViewCell {

    @IBOutlet var imgJudgeIcon: UIImageView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblNameTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
