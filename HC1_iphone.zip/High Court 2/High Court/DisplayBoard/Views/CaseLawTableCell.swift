//
//  CaseLawTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 12/05/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class CaseLawTableCell: UITableViewCell {
    
    @IBOutlet weak var btnTitle: UIButton!
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var constraintWidth: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

    func updateData(object: NSDictionary) {
        let caselaw = CaseLaw(o: object)
        notificationIDs.add(caselaw.id)
        
        self.lblDescription.text = caselaw.description
        self.btnTitle.setTitle(caselaw.title, for: .normal)

        if caselaw.is_read <= 0 {
            viewCell.backgroundColor = UIColor(red: 252/255, green: 246/255, blue: 235/255, alpha: 1)
            self.setBottomBorder(color: UIColor(red: 252/255, green: 246/255, blue: 235/255, alpha: 1))
        } else {
            viewCell.backgroundColor = UIColor.white
            self.setBottomBorder(color: UIColor.white)
        }
    }
    
    func setBottomBorder(color: UIColor) {
        self.btnTitle.titleLabel?.layer.backgroundColor = color.cgColor
        
        self.btnTitle.titleLabel?.layer.masksToBounds = false
        self.btnTitle.titleLabel?.layer.shadowColor = self.btnTitle.titleColor(for: .normal)?.cgColor
        self.btnTitle.titleLabel?.layer.shadowOffset = CGSize(width: 0.0, height: 0.5)
        self.btnTitle.titleLabel?.layer.shadowOpacity = 1.0
        self.btnTitle.titleLabel?.layer.shadowRadius = 0.0
    }
}

struct CaseLaw {
    var description: String = ""
    var title: String = ""
    var is_read: Int = 0
    var id: Int = 0
    var url: String = ""
    
    init(o: AnyObject) {
        caselaw(o: o)
    }
    
    mutating func caselaw(o: AnyObject) {
        let dict = o as? [String: AnyObject]
        
        if let discription = ((dict?["discription"])) {
            self.description = Judge().convertString(a: discription)
        }
        
        if let title = ((dict?["title"])) {
            self.title = Judge().convertString(a: title)
        }
        
        if let isRead = ((dict?["is_read"])) {
            self.is_read = Judge().convertString(a: isRead) != "" ? Int(Judge().convertString(a: isRead))! : 0
        }
        
        if let id = ((dict?["id"])) {
            self.id = Judge().convertString(a: id) != "" ? Int(Judge().convertString(a: id))! : 0
        }
        if let url = ((dict?["url"])) {
            self.url = Judge().convertString(a: url)
        }
    }
}
