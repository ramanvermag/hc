//
//  DisplayBoardTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 03/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class DisplayBoardTableCell: UITableViewCell {
    
    @IBOutlet weak var segmentCell: UISegmentedControl!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        segmentCell.setWidth(Common.s.screenSize.width * 0.16, forSegmentAt: 0)
        segmentCell.setWidth(Common.s.screenSize.width * 0.21, forSegmentAt: 1)
        segmentCell.setWidth(Common.s.screenSize.width * 0.37, forSegmentAt: 2)
        segmentCell.setWidth(Common.s.screenSize.width * 0.26, forSegmentAt: 3)
     
        segmentCell.setEnabled(false, forSegmentAt: 0)
        segmentCell.setEnabled(true , forSegmentAt: 1)
        segmentCell.setEnabled(false, forSegmentAt: 2)
        segmentCell.setEnabled(false, forSegmentAt: 3)
        
        segmentCell.contentHorizontalAlignment = .left
        
        (segmentCell.subviews[3] as UIView).backgroundColor = UIColor.lightGray
        (segmentCell.subviews[3] as UIView).tintColor = UIColor.black
        
//        let segAttributes: NSDictionary = [
//            NSForegroundColorAttributeName: UIColor.black,
////            NSFontAttributeName: UIFont(name: "System-System", size: 14)!
//        ]
        
//        segmentCell.setTitleTextAttributes(segAttributes as [NSObject : AnyObject], for: UIControlState.disabled)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
