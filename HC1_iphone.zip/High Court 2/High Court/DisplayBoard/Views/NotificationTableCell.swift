//
//  NotificationTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 20/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

var notificationIDs = NSMutableSet()
class NotificationTableCell: UITableViewCell {

    @IBOutlet weak var viewText: UIView!
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnDownload: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewText.layer.borderColor = Common.s.appColor.cgColor
        viewText.layer.borderWidth = 1
        viewText.layer.cornerRadius = 10
        
        btnDownload.isHidden = true
//        let w = btnDownload.frame.width
//        btnDownload.titleEdgeInsets = UIEdgeInsetsMake(0,-(w * 0.8), 0, 0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func updateData(object: NSDictionary) {
        let notify = Notify.notify(o: object)
        notificationIDs.add(notify.id)
        
        textView.text = notify.description
        textView.layoutIfNeeded()
        
        lblTime.text  = self.relativePast(date: Date(timeIntervalSince1970: Double(notify.created_at)!))
        btnDownload.isHidden = notify.is_file == "1" ? false : true
        if notify.isRead <= 0 {
            viewText.backgroundColor = UIColor(red: 252/255, green: 246/255, blue: 234/255, alpha: 1)
        } else {
            viewText.backgroundColor = UIColor.white
        }
    }
    
/// Convert Date Time into Year, month, day
    func relativePast(date dateString : Date) -> String {
        let units = Set<Calendar.Component>([.year, .month, .day, .hour, .minute, .second, .weekOfYear])
        let components = Calendar.current.dateComponents(units, from: dateString as Date, to: Date())
        
        var output = ""
        
        if components.year! > 0 {
            output = "\(components.year!) " + (components.year! > 1 ? "years ago" : "year ago")
            
        } else if components.month! > 0 {
            output = "\(components.month!) " + (components.month! > 1 ? "months ago" : "month ago")
            
        } else if components.weekOfYear! > 0 {
            output = "\(components.weekOfYear!) " + (components.weekOfYear! > 1 ? "weeks ago" : "week ago")
            
        } else if (components.day! > 0) {
            output = (components.day! > 1 ? "\(components.day!) days ago" : "Yesterday")
            
        } else if components.hour! > 0 {
            output = "\(components.hour!) " + (components.hour! > 1 ? "Today" : "Today")
            output = "Today"
            
        } else if components.minute! > 0 {
            output = "\(components.minute!) " + (components.minute! > 1 ? "Today" : "Today")
            output = "Today"
            
        } else {
            output = "\(components.second!) " + (components.second! > 1 ? "Today" : "Today")
            output = "Today"
        }
        
        return output
    }
}
