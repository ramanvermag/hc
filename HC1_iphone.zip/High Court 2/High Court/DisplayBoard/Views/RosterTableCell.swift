//
//  RosterTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 12/05/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class RosterTableCell: UITableViewCell {

    @IBOutlet weak var lblSrNo: UILabel!
    @IBOutlet weak var lblBench: UILabel!
    @IBOutlet weak var lblJudge: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lblBench.sizeToFit()
        lblJudge.sizeToFit()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func updateData(object: NSDictionary) {
        let roster = Roster(o: object)
        lblBench.text = roster.benchName
        lblJudge.text = roster.judgeName
    }
    
}

struct Roster {
   var dict = NSDictionary()
    
    init() {
    }
    
    init(o: NSDictionary) {
        dict = o
    }
    
    var title: String {
        return getSet(val: dict.value(forKey: "title"))
    }
    
    var description: String {
        return getSet(val: dict.value(forKey: "description"))
    }
    
    var benchName: String {
        guard let bench = dict.value(forKey: "bench") else { return "" }
        guard let name = (bench as! NSDictionary).value(forKey: "name") else { return "" }
        return getSet(val: name)
    }
    
    var judgeName: String {
        var name = ""
        guard let judge = dict.value(forKey: "judge") else { return "" }
        for n in (judge as! NSArray) {
            let val = getSet(val: (n as! NSDictionary).value(forKey: "name"))
            name = name == "" ? val : name + "\n" + val
        }
        
        return name
    }
    
    func getSet(val: Any?) -> String {
        if val != nil {
            if let notNull =  val as? String {
                return notNull
            } else {
                return ""
            }
        } else {
            return ""
        }
    }
}

class PaddingLabel: UILabel {
    
    @IBInspectable var topInset: CGFloat = 5.0
    @IBInspectable var bottomInset: CGFloat = 5.0
    @IBInspectable var leftInset: CGFloat = 5.0
    @IBInspectable var rightInset: CGFloat = 5.0
    
    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }
    
    override var intrinsicContentSize: CGSize {
        get {
            var contentSize = super.intrinsicContentSize
            contentSize.height += topInset + bottomInset
            contentSize.width += leftInset + rightInset
            return contentSize
        }
    }
}
