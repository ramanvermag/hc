//
//  JudgeDetailTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 20/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeDetailTableCell: UITableViewCell {

    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var lblExt: UILabel!
    @IBOutlet weak var lblExtNo: UILabel!
    @IBOutlet weak var lblDetail: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        lblDetail.frame.size.height = CGFloat.greatestFiniteMagnitude
        lblDetail.sizeToFit()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func hideLabel(detail: Bool) {
        var hide = false
        if detail == false {
            hide = true
        }
        
        lblDetail.isHidden = detail
        lblType.isHidden   = hide
        lblValue.isHidden  = hide
    }
}
