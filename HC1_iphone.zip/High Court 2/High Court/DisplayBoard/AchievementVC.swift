//
//  AchievementVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 24/05/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class AchievementVC: UIViewController {

    @IBOutlet weak var constraintImgTop: NSLayoutConstraint!
    @IBOutlet weak var lblWelcome: UILabel!
    @IBOutlet weak var constraintImgHeightt: NSLayoutConstraint!
    @IBOutlet weak var constraintImgWidth: NSLayoutConstraint!
    @IBOutlet weak var textViewDesc: UITextView!
    @IBOutlet weak var imgUser: UIImageView!
    
    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var constraintViewTopHeight: NSLayoutConstraint!
    
    var achievement = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialise()
        self.loadAchievements()
    }
    
    func initialise() {
        self.lblWelcome.text = ""
        self.textViewDesc.text = ""
        
        if Common.s.screenSize.height < 667 {
            
        }
        
//        self.constraintImgWidth.constant = self.imgUser.bounds.height
        
        self.imgUser.setNeedsLayout()
        Common.s.cornerRadius(img: imgUser)
        print("image width: \(self.imgUser.bounds.width) - \(self.constraintImgWidth.constant)\nimage height: \(self.imgUser.bounds.height)")
        print("total: \(Common.s.screenSize.height), 40%: \((Common.s.screenSize.height * 40)/100) ")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        textViewDesc.setContentOffset(CGPoint.zero, animated: false)
    }
    
    func loadAchievements() {
        Api.s.post(controller: self, method: Api.s.achievement, param: ["":""]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    let achieve = result?.value(forKey: "achievement") as! NSDictionary
                    self.updateData(object: achieve)
                } else {
                    
                }
            } else {
                
            }
        }
    }
    
    func updateData(object: NSDictionary) {
        let model = Achievement(o: object)
        ApiData.s.setImage(image: self.imgUser, img: model.image)
        self.lblWelcome.text = model.title + "\n" + model.destination
        
        if Common.s.screenSize.height <= 568 {
            constraintImgTop.constant = 0
        }
        let attr = NSMutableAttributedString(string: self.lblWelcome.text!)
        attr.addAttributes([NSFontAttributeName: UIFont.systemFont(ofSize: 20)], range: (self.lblWelcome.text! as NSString).range(of: model.destination))
        self.lblWelcome.attributedText = attr
        
        self.textViewDesc.text = model.description
        let htmlData = NSString(string: model.description).data(using: String.Encoding.unicode.rawValue)
        let attributedString = try! NSAttributedString(data: htmlData!, options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType], documentAttributes: nil)
        self.textViewDesc.attributedText = attributedString
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}

struct Achievement {
    var dict = NSDictionary()
    
    init() {
    }
    
    init(o: NSDictionary) {
        dict = o
    }
    
    var description: String {
        guard let variable = dict.value(forKey: "description") else { return "" }
        return Roster().getSet(val: variable)
    }
    
    var destination: String {
        guard let variable = dict.value(forKey: "destination") else { return "" }
        return Roster().getSet(val: variable)
    }
    
    var title: String {
        guard let variable = dict.value(forKey: "title") else { return "" }
        return Roster().getSet(val: variable)
    }
    
    var image: String {
        guard let variable = dict.value(forKey: "image") else { return "" }
        return Roster().getSet(val: variable)
    }
}
