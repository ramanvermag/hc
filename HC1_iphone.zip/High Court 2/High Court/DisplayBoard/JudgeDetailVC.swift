//
//  JudgeDetailVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 20/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeDetailVC: UIViewController {

    @IBOutlet weak var imgJudge: UIImageView!
    @IBOutlet weak var lblJudgeName: UILabel!

    @IBOutlet weak var tableView: UITableView!

    var extNo = ""
    var judgeDetail = NSDictionary()
    let arrTitle = ["LANDLINE", "ADDRESS", "D.O.B","Date of Appointment as Judge", "Date of Retirement as Judge", ""]
    var arrValue = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Common.s.tableSeperator(tableView: self.tableView)
        self.judgedata()
    }
    
    func judgedata() {
        let judge = Judge(o: self.judgeDetail)
        self.arrValue = [judge.landline, judge.address, judge.dob, judge.date_of_appointment, judge.landline, judge.bio_graphy]
        self.extNo = judge.ext_no
        
        self.lblJudgeName.text = judge.name
        let imageUrl = URL(string: judge.imgJudge)
        self.imgJudge.kf.setImage(with: imageUrl, placeholder: #imageLiteral(resourceName: "defaultJudge"), options: [.transition(.fade(0.1))], progressBlock: nil, completionHandler: nil)
        Common.s.cornerRadius(img: self.imgJudge)
        self.tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
extension JudgeDetailVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrValue.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JudgeDetailTableCell", for: indexPath) as! JudgeDetailTableCell
        cell.hideLabel(detail: true)
        
        cell.lblExt.isHidden   = true
        cell.lblExtNo.isHidden = true
        
        if indexPath.row == 0 {
            cell.lblExt.isHidden   = false
            cell.lblExtNo.isHidden = false
            cell.lblExtNo.text = self.extNo
        }

        cell.lblType.text  = self.arrTitle[indexPath.row]
        cell.lblValue.text = self.arrValue[indexPath.row]
        
        if indexPath.row == 5 {
            cell.hideLabel(detail: false)
            cell.lblDetail.text = self.arrValue[indexPath.row]
        }

        return cell
    }
}
extension JudgeDetailVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var height = 65.0
        if indexPath.row == 5 {
            height = Double(Common.s.getHeight(messageString: self.arrValue[indexPath.row]))
        } else if indexPath.row == 1 {
            height = 48.0 + Double(Common.s.getHeight(messageString: self.arrValue[indexPath.row]))
        }
        return CGFloat(height)
    }
}
