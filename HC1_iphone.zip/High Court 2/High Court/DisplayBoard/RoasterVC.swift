//
//  RoasterVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class RoasterVC: UIViewController {

    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var lblHeaderSrNo: UILabel!
    @IBOutlet weak var lblHeaderBench: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    var searchText = ""
    
    var list = NSMutableArray()
    var load_more = true
    var page_no   = 1
    
    var rosterPopup = RosterPopupVC()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.rosterPop()
        
        self.setBottomBorder()
        Common.s.tableSeperator(tableView: self.tableView)
        self.loadMore()
    }
    
    func rosterPop() {
        self.rosterPopup = self.storyboard?.instantiateViewController(withIdentifier: "RosterPopupVCID") as! RosterPopupVC
        rosterPopup.view.frame = self.view.bounds
        rosterPopup.view.backgroundColor = UIColor.clear
        rosterPopup.view.alpha = 0
        self.view.addSubview(rosterPopup.view)
    }
    
    func setBottomBorder() {
        self.viewHeader.layer.backgroundColor = UIColor.white.cgColor
        
        self.viewHeader.layer.masksToBounds = false
        self.viewHeader.layer.shadowColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1).cgColor
        self.viewHeader.layer.shadowOffset = CGSize(width: 0.0, height: 0.5)
        self.viewHeader.layer.shadowOpacity = 1.0
        self.viewHeader.layer.shadowRadius = 0.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func loadMore() {
        if self.load_more {
            self.loadMembers(page: self.page_no)
        }
    }
    
    func loadMembers(page: Int) {
        var param = ["":""]
        if self.searchText != "" {
            param = ["RosterSearch[title]" : self.searchText]
        }
        Api.s.post(controller: self, method: Api.s.roster + "?page=\(page)", param: param as NSDictionary) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    if self.searchText != "" {
                        if page == 1 {
                            self.list.removeAllObjects()
                        }
                    }
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    self.tableView.reloadData()
                } else {
                    
                }
            } else {
                
            }
            if let pagination = result?.value(forKey: "pagination") {
                if let load_more = (pagination as! NSDictionary).value(forKey: "load_more") {
                    self.load_more = load_more as! Bool
                    self.page_no = self.page_no + 1
                }
                
            }
        }
    }
}

extension RoasterVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RosterTableCell", for: indexPath) as! RosterTableCell
        
        cell.lblSrNo.text = "\(indexPath.row + 1)"
        
        cell.updateData(object: self.list[indexPath.row] as! NSDictionary)

        if indexPath.row == self.list.count - 1 {
            self.loadMore()
        }
        
        return cell
    }
}
extension RoasterVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let roster = Roster(o: self.list[indexPath.row] as! NSDictionary)
        let benchHeight = Common.s.getHeight(messageString: roster.benchName)
        let judgeHeight = Common.s.getHeight(messageString: roster.judgeName)
        
        let maximum = max(benchHeight, judgeHeight)
        return indexPath.row == 0 ? maximum + 50 : maximum + 30
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let roster = Roster(o: self.list[indexPath.row] as! NSDictionary)
        
        UIView.animate(withDuration: 0.32, delay: 0.0, options: .curveEaseInOut, animations: { 
            self.rosterPopup.view.alpha = 1
            self.rosterPopup.lblTitle.text = roster.title
            self.rosterPopup.textViewDesc.text = roster.description
        }, completion: nil)

    }
}

extension RoasterVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        if searchText.characters.count == 0 {
            self.list.removeAllObjects()
            self.searchBar.resignFirstResponder()
            self.page_no = 1
            self.load_more = true
            self.loadMore()
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        self.page_no = 1
        self.load_more = true
        self.loadMore()
    }
}
