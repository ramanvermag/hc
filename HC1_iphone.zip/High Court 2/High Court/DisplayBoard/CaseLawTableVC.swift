//
//  CaseLawTableVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class CaseLawTableVC: UITableViewController {
    
    var list = NSMutableArray()
    var load_more = true
    var page_no   = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationIDs.removeAllObjects()
        
        Common.s.tableSeperator(tableView: self.tableView)
        self.loadMore()
    }
    
    func loadMore() {
        if self.load_more {
            self.loadMembers(page: self.page_no)
        }
    }
    
    func loadMembers(page: Int) {
        let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
        Api.s.postHeader(controller: self, method: Api.s.caselaw + "?page=\(page)", param: ["":""], header: ["highcourt-header-token" : "\(token!)"]) { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    self.list.addObjects(from: result?.value(forKey: "list") as! [Any])
                    
                    let descriptor: NSSortDescriptor = NSSortDescriptor(key: "created_at", ascending: true)
                    self.list.sort(using: [descriptor])
                    
                    self.tableView.reloadData()
                } else {
                    
                }
            } else {
                
            }
            if let pagination = result?.value(forKey: "pagination") {
                if let load_more = (pagination as! NSDictionary).value(forKey: "load_more") {
                    self.load_more = load_more as! Bool
                    self.page_no = self.page_no + 1
                }
                
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem) {
        print("\n\nselected array ids - ", notificationIDs.description)
        var iids = [String]()
        notificationIDs.forEach { (id) in
            iids.append("\(id)")
        }
        print(iids[0])
        let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
        Api.s.postHeader(controller: self, method: Api.s.caselawRead, param: ["Notification[notification_id]": iids], header: ["highcourt-header-token" : "\(token!)"], completion: { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    notifyRead["caselaw"] = true
                    _ = self.navigationController?.popViewController(animated: true)
                } else {
                    _ = self.navigationController?.popViewController(animated: true)
                }
            } else {
                _ = self.navigationController?.popViewController(animated: true)
            }
        })
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.list.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CaseLawTableCell", for: indexPath) as! CaseLawTableCell

        cell.updateData(object: self.list[indexPath.row] as! NSDictionary)
        cell.btnTitle.addTarget(self, action: #selector(btnTitleAction(_:)), for: .touchUpInside)
        cell.btnTitle.tag = indexPath.row
        
        if indexPath.row == self.list.count - 1 {
            self.loadMore()
        }
        return cell
    }
 
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let desc = CaseLaw(o: self.list[indexPath.row] as! NSDictionary)
        return CGFloat(82.0 + Double(Common.s.getHeight(messageString: desc.description)))
    }

    func btnTitleAction(_ sender: UIButton) {
        let caselaw = CaseLaw(o: self.list[sender.tag] as! NSDictionary)
        guard caselaw.url != "" else {
            return
        }
        var uri = caselaw.url
        if !uri.contains("http") {
            uri = "http://" + uri
        }
        let url = URL(string: uri)
        print(url!)
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url!, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url!)
        }
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
