//
//  DisplayBoardVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 03/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class DisplayBoardVC: UIViewController {

    @IBOutlet weak var segmentTopbar: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        segmentTopbar.setWidth(Common.s.screenSize.width * 0.16, forSegmentAt: 0)
        segmentTopbar.setWidth(Common.s.screenSize.width * 0.21, forSegmentAt: 1)
        segmentTopbar.setWidth(Common.s.screenSize.width * 0.37, forSegmentAt: 2)
        segmentTopbar.setWidth(Common.s.screenSize.width * 0.26, forSegmentAt: 3)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension DisplayBoardVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DisplayBoardTableCell", for: indexPath) as! DisplayBoardTableCell
        cell.segmentCell.setTitle("\(indexPath.row).", forSegmentAt: 0)
        cell.segmentCell.setImage(UIImage(named: "user"), forSegmentAt: 1)
        cell.segmentCell.setTitle("\(indexPath.row)", forSegmentAt: 2)
        cell.segmentCell.setTitle("220", forSegmentAt: 3)
        
        return cell
    }
}
