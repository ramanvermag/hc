//
//  RosterPopupVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 14/05/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class RosterPopupVC: UIViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var viewDisplay: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var textViewDesc: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)

        btnClose.layer.cornerRadius = btnClose.bounds.midY
        viewDisplay.layer.cornerRadius = 10
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        textViewDesc.setContentOffset(CGPoint.zero, animated: false)
    }
    
    @IBAction func btnCloseAction(_ sender: UIButton) {
//        self.dismiss(animated: true, completion: nil)
        UIView.animate(withDuration: 0.32, delay: 0.0, options: .curveEaseInOut, animations: { 
            self.view.alpha = 0
        }, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
