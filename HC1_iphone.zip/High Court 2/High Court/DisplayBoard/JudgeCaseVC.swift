//
//  JudgeCaseVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 03/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class JudgeCaseVC: UIViewController {

    let arrJudgeCaseIcon  = ["Honrable", "enrol"]
    let arrJudgeCaseTitle = ["JUDGE", "CASE"]
    let arrJudgeCaseName  = ["GAGANDEEP SINGH", "303"]
    
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

extension JudgeCaseVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JudgeCaseTableCell", for: indexPath) as! JudgeCaseTableCell
        cell.imgJudgeIcon.image = UIImage(named: self.arrJudgeCaseIcon[indexPath.row])
        cell.lblNameTitle.text = self.arrJudgeCaseTitle[indexPath.row]
        cell.lblName.text = self.arrJudgeCaseName[indexPath.row]
        return cell
    }
}

extension JudgeCaseVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.tableView.frame.height / CGFloat(2)
    }
}
