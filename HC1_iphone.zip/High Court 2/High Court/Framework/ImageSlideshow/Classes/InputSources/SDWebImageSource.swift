//
//  SDWebImageSource.swift
//  ImageSlideshow
//
//  Created by Nik Kov on 06.07.16.
//
//

//import SDWebImage
import Foundation
import UIKit

/// Input Source to image using SDWebImage
public class SDWebImageSource: NSObject, InputSource {
    var url: URL
    var placeholder: UIImage?

    /// Initializes a new source with a URL
    /// - parameter url: a url to be loaded
    public init(url: URL) {
        self.url = url
        super.init()
    }

    /// Initializes a new source with URL and placeholder
    /// - parameter url: a url to be loaded
    /// - parameter placeholder: a placeholder used before image is loaded
    public init(url: URL, placeholder: UIImage) {
        self.url = url
        self.placeholder = placeholder
        super.init()
    }

    /// Initializes a new source with a URL string
    /// - parameter urlString: a string url to be loaded    
    public init?(urlString: String) {
        if let validUrl = URL(string: urlString) {
            self.url = validUrl
            super.init()
        } else {
            return nil
        }
    }

    public func load(to imageView: UIImageView, with callback: @escaping (UIImage) -> ()) {
        imageView.kf.setImage(with: self.url, placeholder: self.placeholder, options: [.transition(.fade(0.1))], progressBlock: { (receiveSize, totalSize) in
            print("Image progress: \(receiveSize)/\(totalSize)")
        }) { (image, error, cacheType, imageUrl) in
            if let image = image {
                callback(image)
            }
        }
//        imageView.sd_setImage(with: self.url, placeholderImage: self.placeholder, options: [], completed: { (image, _, _, _) in
//            if let image = image {
//                callback(image)
//            }
//        })
    }
}
