//
//  Members.swift
//  High Court
//
//  Created by Karun Aggarwal on 04/05/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

struct Members {
    var imgUrl: String
    let name: String
    let contact: String
    let contactSecond: String
    
    static func member(o: AnyObject) -> Members {
        guard
            let dic = o as? [String: AnyObject],
            let name = dic["name"] as? String,
            let mobile = dic["mobile"] as? String,
            let imageUrl = dic["profilePic"] as? String,
            let landline = dic["landline"] as? String
            else {
                return Members(imgUrl: "", name: "", contact: "", contactSecond: "")
        }
        return Members(imgUrl: imageUrl, name: name, contact: landline, contactSecond: mobile)
    }
}

struct Notify {
    let description: String
    let is_file: String
    let created_at: String
    let notification_src: String
    let isRead: Int
    let id: String
    
    static func notify(o: AnyObject) -> Notify {
        let dict = o as? [String: AnyObject]
//        let desc = dict?["description"]
//        let is_file = dict?["is_file"]
//        let created_at = dict?["created_at"]
//        guard let notification_src = dict?["notification_src"] as? String
//            else {
//                return Notify(description: desc as! String, is_file: is_file as! String, created_at: created_at as! String, notification_src: "")
//        }
//        
//        
//        let returnString = Notify(description: desc as! String, is_file: is_file as! String, created_at: created_at as! String, notification_src: notification_src)
//        
//        guard ((dict?["description"] as? String) != nil) else {
//            return returnString
//        }
//        guard ((dict?["is_file"] as? String) != nil) else {
//            return returnString
//        }
//        guard ((dict?["created_at"] as? String) != nil) else {
//            return returnString
//        }
        
        var desc: String {
            guard let court = dict?["description"] else { return "" }
            return Roster().getSet(val: court)
        }
        
        var is_file: String {
            guard let court = dict?["is_file"] else { return "" }
            return Roster().getSet(val: court)
        }
        
        var created_at: String {
            guard let court = dict?["created_at"] else { return "" }
            return Roster().getSet(val: court)
        }
        var notification_src: String {
            guard let court = dict?["notification_src"] else { return "" }
            return Roster().getSet(val: court)
        }
        var is_read: Int {
            guard let court = dict?["isRead"] else { return 0 }
            if Roster().getSet(val: court) != "" {
                return Int(Roster().getSet(val: court))!
            } else {
                return 0
            }
        }
        var notify_id: Int {
            guard let court = dict?["id"] else { return 0 }
            if Roster().getSet(val: court) != "" {
                return Int(Roster().getSet(val: court))!
            } else {
                return 0
            }
        }
        
        return Notify(description: desc, is_file: is_file, created_at: created_at, notification_src: notification_src, isRead: is_read, id: notify_id.description)
    }
}
