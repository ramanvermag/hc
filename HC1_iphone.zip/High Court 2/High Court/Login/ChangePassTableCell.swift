//
//  ChangePassTableCell.swift
//  High Court
//
//  Created by Karun Aggarwal on 28/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ChangePassTableCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var btnChangePass: UIButton!
    @IBOutlet weak var btnShowHidePass: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
//        self.btnChangePass.setTitle("CHANGE PASSWORD", for: .normal)
//        self.btnChangePass.setImage(UIImage() , for: .normal)
//        self.btnChangePass.backgroundColor = UIColor(red: 217/255, green: 162/255, blue: 49/255, alpha: 1)
//        self.btnChangePass.layer.borderColor = UIColor(red: 217/255, green: 162/255, blue: 49/255, alpha: 1).cgColor
//        self.btnChangePass.setTitleColor(UIColor.white, for: .normal)
//        self.btnChangePass.layer.borderWidth = 1
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func btnChangePassAction(_ sender: UIButton) {
    }
    
    @IBAction func btnShowHidePassAction(_ sender: UIButton) {
        UIView.animate(withDuration: 0.34, delay: 0.0, options: .curveEaseInOut, animations: { 
            if sender.image(for: .normal) == ShowHideEye.showEye {
                sender.setImage(ShowHideEye.hideEye, for: .normal)
                self.textField.isSecureTextEntry = false
            } else {
                sender.setImage(ShowHideEye.showEye, for: .normal)
                self.textField.isSecureTextEntry = true
            }
        }, completion: nil)
    }
    
    func succesBtn() {
        self.textField.isHidden = true
        self.btnChangePass.isHidden = false
        self.btnChangePass.setTitle("Password changed Successfully!", for: .normal)
        self.btnChangePass.setImage(UIImage(named: "successIcon") , for: .normal)
        self.btnChangePass.setTitleColor(UIColor(red: 200/255, green: 225/255, blue: 200/255, alpha: 1), for: .normal)
        self.btnChangePass.backgroundColor = UIColor(red: 200/255, green: 225/255, blue: 200/255, alpha: 1)
        self.btnChangePass.layer.borderColor = UIColor(red: 54/255, green: 149/255, blue: 70/255, alpha: 1).cgColor
        self.btnChangePass.layer.borderWidth = 1
    }
}
