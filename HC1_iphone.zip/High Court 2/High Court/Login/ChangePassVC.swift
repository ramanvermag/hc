//
//  ChangePassVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 13/04/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ChangePassVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    let arrPlaceholder = ["Old Password", "New Password", "Confirm Password", ""]
    var textFields: [UITextField] = []
    
    var succes = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnBackAction(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
extension ChangePassVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChangePassTableCell", for: indexPath) as! ChangePassTableCell
        
        cell.textField.delegate = self
        cell.textField.placeholder = self.arrPlaceholder[indexPath.row]
        
        cell.btnChangePass.isHidden = true
        cell.textField.isHidden = false
        cell.btnShowHidePass.isHidden = false
        
        cell.btnChangePass.addTarget(self, action: #selector(self.btnChangePassAction(_:)), for: .touchUpInside)
        
        self.textFields.append(cell.textField)
        
        
        
        if indexPath.row == 3 {
            cell.btnChangePass.isHidden = false
            cell.textField.isHidden = true
            cell.btnShowHidePass.isHidden = true
        }
        return cell
    }
    
    func btnChangePassAction(_ sender: UIButton) {
        var valid = Bool()
        for txtField in 0..<self.textFields.count - 1 {
            valid = Common.s.validateTextfield(sender: self.textFields[txtField], alertText: self.arrPlaceholder[txtField], controller: self)
            if valid {
                return
            }
        }
        if valid == false {
            if self.textFields[1].text != self.textFields[2].text {
                self.navigationController?.present(Common.s.alertMessage("New password doest not match"), animated: true, completion: nil)
            } else {
                let param = ["PasswordResetForm[old_password]" : self.textFields[0].text, "PasswordResetForm[new_password]": self.textFields[1].text]

                let token = ApiData.s.userDefault.value(forKey: UserDefaultVariables.user_id)
                
                Api.s.postHeader(controller: self, method: Api.s.resetPass, param: param as NSDictionary, header: ["highcourt-header-token" : "\(token!)"], completion: { (result) in
                    if result != nil {
                        if result?.value(forKey: "is_success") as! Bool {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "contentViewController") as! UINavigationController
                            self.navigationController?.show(vc, sender: nil)
                        } else {
                            self.present(Common.s.alertMessage(result?.value(forKey: "error") as! String), animated: true, completion: nil)
                        }
                    }
                })
            }
        }
    }
    
}
extension ChangePassVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

extension ChangePassVC: UITextFieldDelegate {
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        let cell = textField.superview?.superview as! ChangePassTableCell
        let index = self.tableView.indexPath(for: cell)
        
        self.textFields[(index?.row)!].text = textField.text! //text
        
        return true
    }
}
