//
//  LoginVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit
import Alamofire

class LoginVC: UIViewController {

    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var txtLicense: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnShowHidePass: UIButton!
    
    @IBOutlet weak var imgLogo: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        viewTop.backgroundColor = UIColor(patternImage: backImage.image(view: viewTop))
        self.view.bringSubview(toFront: self.imgLogo)
        
//        self.txtLicense.text = "P/2011/2011"
//        self.txtPassword.text = "admin123"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func btnShowHidePassAction(_ sender: UIButton) {
        UIView.animate(withDuration: 0.34, delay: 0.0, options: .curveEaseInOut, animations: { 
            if sender.image(for: .normal) == ShowHideEye.showEye {
                sender.setImage(ShowHideEye.hideEye, for: .normal)
                self.txtPassword.isSecureTextEntry = false
            } else {
                sender.setImage(ShowHideEye.showEye, for: .normal)
                self.txtPassword.isSecureTextEntry = true
            }
        }, completion: nil)
    }
    
    @IBAction func btnLoginAction(_ sender: UIButton) {
        let c = Common.s
        if  c.validateTextfield(sender: self.txtLicense, alertText: "License no" , controller: self) == false &&
            c.validateTextfield(sender: self.txtPassword, alertText: "Password", controller: self) == false {
            
            let param = ["LoginForm[enrollment_number]" : self.txtLicense.text!, "LoginForm[password]": self.txtPassword.text!]
            
            Api.s.post(controller: self, method: Api.s.login, param: param as NSDictionary, completion: { (result) in
                if result != nil {
                    if result?.value(forKey: "is_success") as! Bool {
                        
                        let data = ApiData.s.archivedData(data: result?.value(forKey: "user") as Any)
                        ApiData.s.userDefault.set(data, forKey: UserDefaultVariables.user)
                        
                        ApiData.s.userDefault.set(false, forKey: UserDefaultVariables.logout)
                        ApiData.s.userDefault.synchronize()
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "contentViewController") as! UINavigationController
                        self.navigationController?.show(vc, sender: nil)
                    } else {
                        self.present(Common.s.alertMessage(result?.value(forKey: "error") as! String), animated: true, completion: nil)
                    }
                }
            })
        }
    }
    
    @IBAction func btnForgetAction(_ sender: UIButton) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVCID") as! ForgotPasswordVC
////        self.navigationController?.show(vc, sender: nil)
//        self.navigationController?.present(vc, animated: true, completion: nil)
    }
}

struct ShowHideEye {
    static let showEye = #imageLiteral(resourceName: "show-eye")
    static let hideEye = #imageLiteral(resourceName: "hide-eye")
}
