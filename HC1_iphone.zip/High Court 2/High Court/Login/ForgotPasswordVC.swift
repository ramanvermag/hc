//
//  ForgotPasswordVC.swift
//  High Court
//
//  Created by Karun Aggarwal on 18/03/17.
//  Copyright © 2017 Karun Aggarwal. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController {

    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var txtLicense: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewTop.backgroundColor = UIColor(patternImage: backImage.image(view: viewTop))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
//        self.navigationController?.dismiss(animated: true, completion: nil)
        _ = self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnRestPasswordAction(_ sender: UIButton) {
        if Common.s.validateTextfield(sender: self.txtLicense, alertText: "License no ", controller: self) == false {
            let param = ["RequestResetPassword[license_no]": self.txtLicense.text!]
           Api.s.post(controller: self, method: Api.s.requestResetPass, param: param as NSDictionary, completion: { (result) in
            if result != nil {
                if result?.value(forKey: "is_success") as! Bool {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVCID") as! LoginVC
                    self.navigationController?.show(vc, sender: nil)
                } else {
                    self.present(Common.s.alertMessage(result?.value(forKey: "license_no") as! String), animated: true, completion: nil)
                }
            }
           })
        }
    }
}

struct backImage {
    static func image(view: UIView) -> UIImage {
        UIGraphicsBeginImageContext(view.frame.size)
        #imageLiteral(resourceName: "loginBack").draw(in: view.bounds)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
}
